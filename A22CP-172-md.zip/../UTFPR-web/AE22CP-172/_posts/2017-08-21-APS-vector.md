---
layout: post
title: APS - Implementando vector
description: 
author: jean
category: 
tags: aps1-vector
finished: false
date: "2017-08-28 13:50"
---

**Conteúdo**
- Do not remove this line (it will not be displayed)
{:toc}


# Estrutura e implementação

Implementar as funcionalidades da classe `vector`. Para tal utilizar uma estrutura similar a:

```cpp
typedef struct {
    int* data;
    int  size;
    int capacity; 
} vector;
```

## Inicialização e Finalização

Todas a funcionalidades e acesso aos dados será feita por funções, as quais precisaremos definir. A primeira delas, é a função de alocação da memória inicial de um vetor.

```cpp
vector* new_vector(int cap_inicial);
```

De forma análoga há a função para desalocar a memória do vetor e do ponteiro.
```cpp
// Desaloca a memória de v->data e o próprio v
void free_vector(vector* v);
```

## Acesso e manipulação: sem crescimento

Para acessar um item do vetor e alterar o valor de um item, por exemplo:

```cpp
// Retorna um ponteiro para o item na posição i
int* vector_at(vector* v, int i);
// Retorna o valor na posição i
int vector_get(vector* v, int i);
// Altera o valor na posição i
void vector_set(vector* v, int i, int valor);
```

<h2 id="acesso-e-manipulação">Acesso e manipulação</h2>

<h3 id="inserção-com-crescimento">Inserção: com crescimento</h3>
<p>As funções acima não alteram o tamanho do vetor, portanto $i$ deve ser um índice válido. Já a função a seguir, tenta inserir um item no final do vetor, caso ainda haja espaço, basta inserí-lo e atualizar <code class="highlighter-rouge">size</code>. Caso contrário, é preciso realocar o vetor.</p>
<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="kt">void</span> <span class="n">vector_push_back</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">,</span> <span class="kt">int</span> <span class="n">value</span><span class="p">);</span>
</code></pre>
</div>

<p>Suponha agora que queiramos inserir um elemento no vetor em uma dada posição que não seja o fim. Chamaremos essa função:</p>
<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="kt">void</span> <span class="n">vector_insert</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">,</span> <span class="kt">int</span> <span class="n">value</span><span class="p">,</span> <span class="kt">int</span> <span class="n">i</span><span class="p">);</span>
</code></pre>
</div>

<p>Se <code class="highlighter-rouge">vector_insert</code> é chamada para inserir um valor em uma posição $i$ do vetor, todos os elementos em posições posteriores a $i$ precisam ser movidos adiante.</p>

<p>Implementada a inserção, temos condições de facilmente implementar uma função para inserir no início do vetor. Esta função precisa apenas chamar <code class="highlighter-rouge">vector_insert(v, value, 0)</code>.</p>
<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="kt">void</span> <span class="n">vector_push_front</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">,</span> <span class="kt">int</span> <span class="n">value</span><span class="p">);</span>
</code></pre>
</div>

<h3 id="remoção-sem-decrescimento">Remoção: sem decrescimento</h3>

<p>De forma análoga às funções de inserção, temos as funções para remoção de elementos do vetor. Essas, no entanto, não alteram a capacidade do vetor, apenas seu tamanho. O funcionamento dessas funções é semelhante às anteriores.</p>

<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="c1">// Remove o elemento do fim do vetor, decrementando size.
</span><span class="kt">int</span> <span class="n">vector_pop_back</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">);</span>
<span class="c1">// Remove o elemento na posição i, e move os posteriores para trás
</span><span class="kt">int</span> <span class="n">vector_erase</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">,</span> <span class="kt">int</span> <span class="n">i</span><span class="p">);</span>
<span class="c1">// Remove o elemento na posição zero do vetor e move os posteriores para trás
</span><span class="kt">int</span> <span class="n">vector_pop_front</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">);</span>
</code></pre>
</div>

<h2 id="atualizando-o-tamanho-do-vetor-resize">Atualizando o tamanho do vetor: resize</h2>

<p>Sempre que um elemento for inserido no vetor, uma alteração no tamanho atual (<code class="highlighter-rouge">size</code>) é necessária.</p>
<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="kt">void</span> <span class="n">resize</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">);</span>
</code></pre>
</div>

<p>Se não há espaço adicional (entre <code class="highlighter-rouge">size</code> e <code class="highlighter-rouge">capacity</code>) é preciso realocar o vetor <code class="highlighter-rouge">realloc</code>. Assumiremos que a nova capacidade será o dobro da atual <code class="highlighter-rouge">capacity *= 2</code>. Observe que se a capacidade for inicializada com zero, esta atualização não funcionará.</p>

<h2 id="imprimindo-o-conteúdo-do-vetor">Imprimindo o conteúdo do vetor</h2>

<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="kt">void</span> <span class="n">vector_print</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">);</span>
</code></pre>
</div>
<p>Esta função auxiliar deverá imprimir o conteúdo do vetor obedecendo o seguinte formato:</p>

<div class="highlighter-rouge"><pre class="highlight"><code>[size/capacity] data[0] data[1] data[2] ... data[size] \n
</code></pre>
</div>

<p>Exemplo:</p>
<div class="highlighter-rouge"><pre class="highlight"><code>[6/10] 0 1 8 2 3 9
</code></pre>
</div>

<h2 id="verificando-a-validade-de-argumentos">Verificando a validade de argumentos</h2>

<p>Grande parte das funções de acesso e manipulação dos dados no vetor recebem como argumento um inteiro como índice. Para o contexto de <code class="highlighter-rouge">vector</code>, todo acesso que não esteja no intervalo $0 \leq i &lt; \mbox{size}$ é inválido, pois extrapola os índices do vetor.</p>

<p>Há diversas formas de se verificar esse tipo de situação. Podemos, por exemplo, definir um condicional que verifique os limites de $i$</p>
<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="k">if</span> <span class="p">(</span><span class="n">i</span> <span class="o">&gt;=</span> <span class="mi">0</span> <span class="o">&amp;&amp;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">v</span><span class="o">-&gt;</span><span class="n">size</span><span class="p">)</span> <span class="p">{</span>
    <span class="c1">// Faz algo
</span><span class="p">}</span>
</code></pre>
</div>

<p>No caso de vector, um acesso fora dos limites do vetor levaria a uma falha de segmentação durante a execução do programa. Um acesso desse tipo, em geral, é resultado de erro de programação, visto que não é razoável que alguém tente, deliberadamente, acessar uma região de memória que não lhe pertence. Portanto, acessos desse tipo são anômalos, e devem ser noticiados imediatamente.</p>

<p>Uma forma de se fazer isso, é utilizando a função <code class="highlighter-rouge">assert(bool v)</code> (requer <code class="highlighter-rouge">#include &lt;assert.h&gt;</code>). Esta é uma função bem simples, a qual termina a execução do programa, caso o argumento que ela receba não seja verdadeiro. O condicional definido anteriormente poderia ser substituído por:</p>
<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="n">assert</span><span class="p">(</span><span class="n">i</span> <span class="o">&gt;=</span><span class="mi">0</span> <span class="o">&amp;&amp;</span> <span class="n">i</span> <span class="o">&lt;</span> <span class="n">v</span><span class="o">-&gt;</span><span class="n">size</span><span class="p">);</span>
<span class="c1">// Faz algo
</span></code></pre>
</div>

<p>Neste caso, a linha após <code class="highlighter-rouge">assert</code> somente será alcançada caso a expressão <code class="highlighter-rouge">i &gt;=0 &amp;&amp; i &lt; v-&gt;size</code> seja verdadeira. Caso contrário o programa será interrompido imediatamente, e uma mensagem de erro impressa em tela.</p>

<h1 id="generalizando-o-tipo-vector">Generalizando o tipo vector</h1>

<p>Até então tratamos de uma implementação <code class="highlighter-rouge">vector</code> cuja estrutura interna é baseada em um vetor de inteiros.</p>
<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="k">typedef</span> <span class="k">struct</span> <span class="p">{</span>
    <span class="kt">int</span><span class="o">*</span> <span class="n">data</span><span class="p">;</span>     <span class="c1">// vetor que armazenará os inteiro;
</span>    <span class="kt">int</span>  <span class="n">size</span><span class="p">;</span>     <span class="c1">// tamanho atual do vetor
</span>    <span class="kt">int</span>  <span class="n">capacity</span><span class="p">;</span> <span class="c1">// tamanho reservado em memória 
</span><span class="p">}</span> <span class="n">vector</span><span class="p">;</span>
</code></pre>
</div>

<p>Porém, em grande parte dos casos, as mesmas funcionalidades implementadas poderiam ser úteis para outros tipos de dados. Como poderíamos alterar essa estrutura para que fosse mais fácil utilizá-la em outras situações? Ex.: para armazenar <code class="highlighter-rouge">float</code> ou <code class="highlighter-rouge">char</code>, etc.</p>

<p>Podemos definir um tipo de dados, com <code class="highlighter-rouge">typedef</code> e utilizá-lo em lugar de <code class="highlighter-rouge">int</code>. Ou seja</p>
<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="k">typedef</span> <span class="kt">int</span> <span class="n">Type</span><span class="p">;</span>

<span class="k">typedef</span> <span class="k">struct</span> <span class="p">{</span>
    <span class="n">Type</span><span class="o">*</span> <span class="n">data</span><span class="p">;</span>     <span class="c1">// vetor que armazenará os inteiro;
</span>    <span class="kt">int</span>  <span class="n">size</span><span class="p">;</span>     <span class="c1">// tamanho atual do vetor
</span>    <span class="kt">int</span>  <span class="n">capacity</span><span class="p">;</span> <span class="c1">// tamanho reservado em memória 
</span><span class="p">}</span> <span class="n">vector</span><span class="p">;</span>
</code></pre>
</div>

<p>Toda a referência ao tipo inteiro em elementos do vetor, são agora substituídos por <code class="highlighter-rouge">Type</code>. Deste modo para que se utilize toda a estrutura com um tipo de dados diferente, basta alterar a definição de <code class="highlighter-rouge">Type</code>.</p>

<div class="language-cpp highlighter-rouge"><pre class="highlight"><code><span class="k">typedef</span> <span class="kt">float</span> <span class="n">Type</span><span class="p">;</span>
<span class="c1">// Funções de remoção de elementos
</span><span class="n">Type</span> <span class="n">vector_pop_back</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">);</span>
<span class="n">Type</span> <span class="n">vector_pop_front</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">);</span>
<span class="n">Type</span> <span class="n">vector_erase</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">,</span> <span class="kt">int</span> <span class="n">i</span><span class="p">);</span>
<span class="c1">// Funções de inserção de elementos
</span><span class="kt">void</span> <span class="n">vector_push_back</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">,</span> <span class="n">Type</span> <span class="n">value</span><span class="p">);</span>
<span class="kt">void</span> <span class="n">vector_push_front</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">,</span> <span class="n">Type</span> <span class="n">value</span><span class="p">);</span>
<span class="kt">void</span> <span class="n">vector_insert</span><span class="p">(</span><span class="n">vector</span><span class="o">*</span> <span class="n">v</span><span class="p">,</span> <span class="n">Type</span> <span class="n">value</span><span class="p">,</span> <span class="kt">int</span> <span class="n">i</span><span class="p">);</span>
<span class="p">...</span>
</code></pre>
</div>

<h1 id="casos-de-teste">Casos de teste</h1>

<p>Um caso de teste é um conjunto de dados de entrada com a respectiva saída esperada. Há diversos meios de se implementar casos de testes (<a href="https://pt.wikipedia.org/wiki/Teste_de_unidade">wiki/Teste_de_unidade</a>), no entanto, para o nosso propósito isso será feito por meio de um arquivo de entrada, e um arquivo de saída. Considera-se que o programa passou em um determinado caso de teste, se, dado um arquivo de entrada, ele produz um arquivo de saída idêntico ao esperado.</p>

<p>Suponhamos o seguinte arquivo de entrada, o qual especifica um caso de teste.</p>

<div class="highlighter-rouge"><pre class="highlight"><code>6
6
push_front 13
push_back 49
push_back 29
push_back 5
push_front 26
pop_back
</code></pre>
</div>

<p>Após cada um desses comandos o vetor é impresso, seguindo um formato especificado descrito a seguir:</p>

<div class="highlighter-rouge"><pre class="highlight"><code>[1/6] 13 
[2/6] 13 49 
[3/6] 13 49 29 
[4/6] 13 49 29 5 
[5/6] 26 13 49 29 5 
[4/6] 26 13 49 29 
</code></pre>
</div>

<p>A primeira linha do arquivo de entrada sempre inicializará o vetor, neste exemplo, ela requisita a inicialização com capacidade 6</p>
<div class="highlighter-rouge"><pre class="highlight"><code>6
</code></pre>
</div>

<p>A pŕoxima linha indica quantos comandos virão a seguir, neste exemplo temos 6 comandos, portanto a segunda linha contém o número 6.</p>

<p>A seguir desta linha, virão então 9 comandos, que serão lidos um a um. A cada comando lido, a função de mesmo nome deverá ser chamada no seu código com os parâmetros vindos do arquivo. Exemplo, a linha de entrada</p>

```
push_front 13
```
<p>Deverá disparar em seu código uma chamada à função</p>


```cpp
vector_push_front(v, 13);
```

<p>Note que cada linha nessa saída é resultado de um dos comandos de entrada. Por exemplo, após o primeiro <code class="highlighter-rouge">push_front 13</code>, o vetor passa a ter tamanho 1 e capacidade 6, portanto foi impresso em tela a linha</p>
<div class="highlighter-rouge"><pre class="highlight"><code>[1/6] 13
</code></pre>
</div>

<p>Após o segundo <code class="highlighter-rouge">push_back 49</code>, o vetor passa a ter tamanho 2 e capacidade ainda é 6, portanto foi impresso em tela a linha</p>
<div class="highlighter-rouge"><pre class="highlight"><code>[2/6] 13 49
</code></pre>



