---
layout: post
title: APS3 - Algoritmos de ordenação
description: 
author: jean
category: 
tags: ordenação
finished: false
date: "2017-10-20 13:50"
---

**Conteúdo**
- Do not remove this line (it will not be displayed)
{:toc}


# Objetivos

Comparar experimentalmente os algoritmos de ordenação em diferentes cenários. Identificar a relação entre os tipos de entradas e a eficiência desses algoritmos.

# Motivação

Aprender a identificar qual algoritmo utilizar para ordenação de dados em um determinado contexto.

# Experimentos

Todos algoritmos deverão ser executados para os mesmos casos de teste e depois comparados quanto ao **tempo médio** e ao **número de comparações**. Nesta seção descrevo em detalhes como isso pode ser feito.

## Entrada

Teremos diversos arquivos de entrada de nome `input_e.txt`, onde $e=1,2,\dots,15$, todos eles contendo $100$ sequências numéricas, uma por linha. 

Cada sequência contém $n=10 \times 2^e$ elementos numéricos, ou seja indica $n$ indica o tamanho das sequências que esse arquivo contém. Exemplo:

  - O arquivo `input_1.txt`, conterá `100` linhas.
    - Cada linha representa uma sequência a ser ordenada, contendo $n=10\times 2^1 = 20$ elementos.
  - O arquivo `input_3.txt`, conterá `100` linhas.
    - Cada linha representa uma sequência a ser ordenada, contendo $n=10\times 2^3 = 80$ elementos.
  - O arquivo `input_15.txt`, conterá `100` linhas.
    - Cada linha representa uma sequência a ser ordenada, contendo $n=10\times 2^{15} = 327680$ elementos.

Cada cenário de testes (irei explicar os demais adiante), contém então, um conjunto de arquivos da forma:

```
Arquivo          e         n(e)=10 * 2^e
input_1.txt      1         20
input_2.txt      2         40
input_3.txt      3         80
input_4.txt      4         160
input_5.txt      5         320
input_6.txt      6         640
input_7.txt      7         1280
input_8.txt      8         2560
input_9.txt      9         5120
input_10.txt     10        10240
input_11.txt     11        20480
input_12.txt     12        40960
input_13.txt     13        81920
input_14.txt     14        163840
input_15.txt     15        327680
```

Teremos, então, sequências de tamanhos que crescem exponencialmente. Isso serve para observarmos o comportamento dos algoritmos em sequências pequenas e em sequências grandes. Alguns deles podem ser rápidos para sequências pequenas, enquanto outros podem ser mais rápidos em sequências grandes. Isso é algo que gostaríamos de identificar com os experimentos. 

## Execução e medição

Para cada cenário, teremos então um conjunto de $15$ arquivos de entrada, assim como descrito acima. E um certo número de algoritmos de ordenação a serem comparados. Considere a entrada `input_1.txt` e assuma que desejamos comparar 4 algoritmos: 

  - `bubble`, 
  - `selection`, 
  - `insertion` e 
  - `quicksort`. 
  
A primeira etapa consiste em executar cada um desses algoritmos tendo como entrada um arquivo `input_1.txt`. Vamos ilustrar esse procedimento por meio do `bubblesort`.

### Execução exemplo para $n=20$

  1. Primeiramente alteramos o código do `bubblesort` de modo a contar todas as comparações que ele efetua. Inserimos um contador para isso, que será incrementado sempre que dois elementos forem comparados. Ex:
```cpp
if (v[i] < v[i+1]) {
    ncomparacoes++;
    ...
}
```
  2. Ler uma linha do arquivo de entrada e armazená-la num vetor `v` (ou vector, ou lista). Chamar a função de ordenação nesse vetor.
```cpp
long ncomparacoes = 0;
bubblesort(v, vsize);
```
  3. Ler uma nova linha do arquivo e armazená-la outra vez em `v`, chamar a função de ordenação nesse vetor.
```cpp
bubblesort(v, vsize);
```
  4. Repetir esse procedimento até a última linha do arquivo de entrada (centésima linha).
  5. Após a última chamada, teremos o total `ncomparacoes` efetuadas em todas as chamadas a `bubblesort`. Dividindo esse valor por `100`, teremos o número médio esperado de comparações que o `bubblesort` efetua em sequências de tamanho $n=20$ (neste exemplo).

Ao fim deste processo temos um par de valores, relacionado ao tamanho das sequências, e o número médio de comparações do bubblesort $\sigma_b$. Se repetirmos esse procedimento para todos os demais algoritmos teremos para eles outros pares de valores

  - Bubble sort:    $(20, \sigma_b)$ 
  - Selection sort: $(20, \sigma_s)$
  - Insertion sort: $(20, \sigma_i)$
  - Quick sort:     $(20, \sigma_q)$

Assuma que os tempos médios de cada algoritmo sejam, respectivamente, $t_1, t_2, t_3, t_4$. Poderíamos agora iniciar uma comparação gráfica entre eles. Plotando como eixo $x$ os possíveis tamanhos de $n$ e no eixo $y$ os respectivos tempos médios.

### Resultados para todos $n$

Se o procedimento acima for efetuado para todos os arquivos de entrada, ou seja, todos possíveis $n=20,40,80,\dots,327680$, teremos ao final, para cada algoritmo o número médio de comparações em cada $n$. Os quais podemos utilizar para plotar um gráfico e comparar a eficiência desses algoritmos.

  - Bubble sort:    $(20, \sigma_b), (40, \sigma_b), \dots, (327680, \sigma_b)$ 
  - Selection sort: $(20, \sigma_s), (40, \sigma_s), \dots, (327680, \sigma_s)$
  - Insertion sort: $(20, \sigma_i), (40, \sigma_i), \dots, (327680, \sigma_i)$
  - Quick sort:     $(20, \sigma_q), (40, \sigma_q), \dots, (327680, \sigma_q)$


