---
layout: post
title: APS1 - Implementando vector (Resultados)
description: 
author: jean
category: 
tags: aps1-vector
finished: false
date: "2017-09-01 10:50"
---



**Resultados por RA**
- Do not remove this line (it will not be displayed)
{:toc}

## 1544292
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .660
input01.txt            653             10          1,040           .620
input02.txt            224             10            592           .463
input03.txt             84             10            240           .440
input04.txt            850             10          1,552           .782
input05.txt             34             10             80           .459
input06.txt            427             10            784           .518
input07.txt            751             10          1,168           .731
input08.txt            599             10          1,040           .643
input09.txt            402             10            528           .560
input10.txt              9             10             36           .436
input11.txt             10             10             40           .522
input12.txt              2             10             20           .440
input13.txt             10             10             52           .443
input14.txt              2             10             32           .421
input15.txt              9             10             36           .440
input16.txt             11             10             32           .453
input17.txt              7             10             52           .433
input18.txt              3             10             32           .452
input19.txt              7             10             40           .440
```

## 1881906
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .677
input01.txt            653             10              0           .688
input02.txt            224             10              0           .545
input03.txt             84             10              0           .459
input04.txt            850             10              0           .752
input05.txt             34             10              0           .469
input06.txt            427             10              0           .526
input07.txt            751             10              0           .729
input08.txt            599             10              0           .614
input09.txt            402             10              0           .516
input10.txt              9             10              0           .439
input11.txt             10             10              0           .446
input12.txt              2             10              0           .465
input13.txt             10             10              0           .475
input14.txt              2             10              0           .421
input15.txt              9             10              0           .447
input16.txt             11             10              0           .517
input17.txt              7             10              0           .459
input18.txt              3             10              0           .476
input19.txt              7             10              0           .434
```

## 1917366
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .660
input01.txt            653             10          1,040           .645
input02.txt            224              0            592           .614
input03.txt             84              0            240           .630
input04.txt            850              0          1,552           .905
input05.txt             34             10             80           .478
input06.txt            427             10            784           .549
input07.txt            751              0          1,168           .949
input08.txt            599             10          1,040           .661
input09.txt            402             10            528           .516
input10.txt              9             10             36           .443
input11.txt             10             10             40           .467
input12.txt              2             10             20           .482
input13.txt             10             10             52           .458
input14.txt              2             10             32           .446
input15.txt              9             10             36           .496
input16.txt             11             10             32           .455
input17.txt              7             10             52           .442
input18.txt              3             10             32           .449
input19.txt              7             10             40           .483
```

## 1917463
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .740
input01.txt            653             10              0           .674
input02.txt            224             10              0           .518
input03.txt             84             10              0           .580
input04.txt            850             10              0           .860
input05.txt             34             10              0           .459
input06.txt            427             10              0           .525
input07.txt            751             10              0           .808
input08.txt            599             10              0           .679
input09.txt            402             10              0           .588
input10.txt              9             10              0           .480
input11.txt             10             10              0           .438
input12.txt              2             10              0           .427
input13.txt             10             10              0           .474
input14.txt              2             10              0           .456
input15.txt              9             10              0           .444
input16.txt             11             10              0           .465
input17.txt              7             10              0           .466
input18.txt              3             10              0           .478
input19.txt              7             10              0           .454
```

## 23931913
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .688
input01.txt            653             10              0           .697
input02.txt            224             10              0           .496
input03.txt             84             10              0           .459
input04.txt            850             10              0           .831
input05.txt             34             10              0           .460
input06.txt            427             10              0           .512
input07.txt            751             10              0           .708
input08.txt            599             10              0           .624
input09.txt            402             10              0           .591
input10.txt              9             10              0           .458
input11.txt             10             10              0           .457
input12.txt              2             10              0           .432
input13.txt             10             10              0           .436
input14.txt              2             10              0           .434
input15.txt              9             10              0           .450
input16.txt             11             10              0           .436
input17.txt              7             10              0           .442
input18.txt              3             10              0           .442
input19.txt              7             10              0           .460
```

