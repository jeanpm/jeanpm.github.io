---
layout: post
title: APS1 - Implementando vector (Resultados)
description: 
author: jean
category: 
tags: aps1-vector
finished: false
date: "2017-09-01 10:50"
---



**Resultados por RA** ([Comparação-plágio](../AE22CP-172/APS1-jplag), [NotasA](../assets/AE22CP/UTFPR-A22CP-172-Notas-A.pdf), [NotasB](../assets/AE22CP/UTFPR-A22CP-172-Notas-B.pdf)) 
- Do not remove this line (it will not be displayed)
{:toc}
## 1368206
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .712
input01.txt            653             10              0           .615
input02.txt            224             10              0           .502
input03.txt             84             10              0           .434
input04.txt            850             10              0           .745
input05.txt             34             10              0           .430
input06.txt            427             10              0           .498
input07.txt            751             10              0           .696
input08.txt            599             10              0           .590
input09.txt            402             10              0           .505
input10.txt              9             10              0           .429
input11.txt             10             10              0           .423
input12.txt              2             10              0           .408
input13.txt             10             10              0           .424
input14.txt              2             10              0           .408
input15.txt              9             10              0           .427
input16.txt             11             10              0           .426
input17.txt              7             10              0           .425
input18.txt              3             10              0           .423
input19.txt              7             10              0           .423
```

## 1435558
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .689
input01.txt            653             10          1,040           .622
input02.txt            224             10            592           .464
input03.txt             84             10            240           .435
input04.txt            850             10          1,552           .739
input05.txt             34             10             80           .437
input06.txt            427             10            784           .503
input07.txt            751             10          1,168           .700
input08.txt            599             10          1,040           .592
input09.txt            402             10            528           .509
input10.txt              9             10             36           .427
input11.txt             10             10             40           .430
input12.txt              2             10             20           .411
input13.txt             10             10             52           .441
input14.txt              2             10             32           .435
input15.txt              9             10             36           .428
input16.txt             11             10             32           .449
input17.txt              7             10             52           .434
input18.txt              3              0             16          3.478
input19.txt              7             10             40           .581
```

## 1436236
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .671
input01.txt            653             10              0           .695
input02.txt            224             10              0           .477
input03.txt             84             10              0           .460
input04.txt            850             10              0           .754
input05.txt             34             10              0           .450
input06.txt            427             10              0           .509
input07.txt            751             10              0           .722
input08.txt            599             10              0           .616
input09.txt            402             10              0           .518
input10.txt              9             10              0           .472
input11.txt             10             10              0           .458
input12.txt              2             10              0           .423
input13.txt             10             10              0           .433
input14.txt              2             10              0           .425
input15.txt              9             10              0           .437
input16.txt             11             10              0           .459
input17.txt              7             10              0           .460
input18.txt              3             10              0           .454
input19.txt              7             10              0           .427
```

## 1436287
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .687
input01.txt            653             10          1,040           .614
input02.txt            224             10            592           .493
input03.txt             84             10            240           .459
input04.txt            850             10          1,552           .771
input05.txt             34             10             80           .434
input06.txt            427             10            784           .513
input07.txt            751             10          1,168           .731
input08.txt            599             10          1,040           .617
input09.txt            402             10            528           .519
input10.txt              9             10             36           .434
input11.txt             10             10             40           .441
input12.txt              2             10             20           .408
input13.txt             10             10             52           .441
input14.txt              2             10             32           .482
input15.txt              9             10             36           .502
input16.txt             11             10             32           .456
input17.txt              7             10             52           .433
input18.txt              3             10             32           .423
input19.txt              7             10             40           .437
```

## 1454536
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .670
input01.txt            653             10              0           .626
input02.txt            224             10              0           .476
input03.txt             84             10              0           .441
input04.txt            850             10              0           .756
input05.txt             34             10              0           .438
input06.txt            427             10              0           .532
input07.txt            751             10              0           .730
input08.txt            599             10              0           .616
input09.txt            402             10              0           .510
input10.txt              9             10              0           .437
input11.txt             10             10              0           .422
input12.txt              2             10              0           .453
input13.txt             10             10              0           .437
input14.txt              2             10              0           .431
input15.txt              9             10              0           .456
input16.txt             11             10              0           .428
input17.txt              7             10              0           .423
input18.txt              3             10              0           .419
input19.txt              7             10              0           .468
```

## 1454536-v2
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .677
input01.txt            653             10          1,040           .629
input02.txt            224             10            592           .478
input03.txt             84             10            240           .466
input04.txt            850             10          1,552           .764
input05.txt             34             10             80           .439
input06.txt            427             10            784           .511
input07.txt            751             10          1,168           .720
input08.txt            599             10          1,040           .617
input09.txt            402             10            528           .514
input10.txt              9             10             36           .434
input11.txt             10             10             40           .434
input12.txt              2             10             20           .427
input13.txt             10             10             52           .436
input14.txt              2             10             32           .425
input15.txt              9             10             36           .427
input16.txt             11             10             32           .427
input17.txt              7             10             52           .430
input18.txt              3             10             32           .422
input19.txt              7             10             40           .425
```

## 1544292
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .663
input01.txt            653             10              0           .624
input02.txt            224             10              0           .513
input03.txt             84             10              0           .437
input04.txt            850             10              0           .755
input05.txt             34             10              0           .440
input06.txt            427             10              0           .553
input07.txt            751             10              0           .723
input08.txt            599             10              0           .596
input09.txt            402             10              0           .523
input10.txt              9             10              0           .425
input11.txt             10             10              0           .452
input12.txt              2             10              0           .442
input13.txt             10             10              0           .463
input14.txt              2             10              0           .435
input15.txt              9             10              0           .429
input16.txt             11             10              0           .442
input17.txt              7             10              0           .464
input18.txt              3             10              0           .433
input19.txt              7             10              0           .430
```

## 1636847
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .698
input01.txt            653             10          1,040           .662
input02.txt            224             10            592           .476
input03.txt             84             10            240           .471
input04.txt            850             10          1,552           .834
input05.txt             34             10             80           .489
input06.txt            427             10            784           .545
input07.txt            751             10          1,168           .809
input08.txt            599             10          1,040           .763
input09.txt            402             10            528           .587
input10.txt              9             10             36           .677
input11.txt             10             10             40           .641
input12.txt              2             10             20           .460
input13.txt             10             10             52           .487
input14.txt              2             10             32           .419
input15.txt              9             10             36           .446
input16.txt             11             10             32           .525
input17.txt              7             10             52           .577
input18.txt              3             10             32           .442
input19.txt              7             10             40           .464
```

## 1649868
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .716
input01.txt            653             10              0           .690
input02.txt            224             10              0           .492
input03.txt             84             10              0           .644
input04.txt            850             10              0           .992
input05.txt             34             10              0           .464
input06.txt            427             10              0           .537
input07.txt            751             10              0           .741
input08.txt            599             10              0           .655
input09.txt            402             10              0           .567
input10.txt              9             10              0           .521
input11.txt             10             10              0           .451
input12.txt              2             10              0           .493
input13.txt             10             10              0           .465
input14.txt              2             10              0           .430
input15.txt              9             10              0           .436
input16.txt             11             10              0           .449
input17.txt              7             10              0           .426
input18.txt              3             10              0           .428
input19.txt              7             10              0           .437
```

## 1809733
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .693
input01.txt            653             10              0           .638
input02.txt            224             10              0           .496
input03.txt             84             10              0           .463
input04.txt            850             10              0           .787
input05.txt             34             10              0           .441
input06.txt            427             10              0           .536
input07.txt            751             10              0           .759
input08.txt            599             10              0           .679
input09.txt            402             10              0           .557
input10.txt              9             10              0           .461
input11.txt             10             10              0           .454
input12.txt              2             10              0           .505
input13.txt             10             10              0           .498
input14.txt              2             10              0           .442
input15.txt              9             10              0           .458
input16.txt             11             10              0           .584
input17.txt              7             10              0           .489
input18.txt              3             10              0           .473
input19.txt              7             10              0           .442
```

## 1809857
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .776
input01.txt            653             10              0           .817
input02.txt            224             10              0           .549
input03.txt             84             10              0           .504
input04.txt            850             10              0           .851
input05.txt             34             10              0           .573
input06.txt            427             10              0           .538
input07.txt            751             10              0           .755
input08.txt            599             10              0           .645
input09.txt            402             10              0           .562
input10.txt              9             10              0           .440
input11.txt             10             10              0           .435
input12.txt              2             10              0           .407
input13.txt             10             10              0           .443
input14.txt              2             10              0           .422
input15.txt              9             10              0           .438
input16.txt             11             10              0           .434
input17.txt              7             10              0           .448
input18.txt              3             10              0           .472
input19.txt              7             10              0           .432
```

## 1811754
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .673
input01.txt            653             10              0           .630
input02.txt            224             10              0           .483
input03.txt             84             10              0           .447
input04.txt            850             10              0           .754
input05.txt             34             10              0           .437
input06.txt            427             10              0           .512
input07.txt            751             10              0           .702
input08.txt            599             10              0           .610
input09.txt            402             10              0           .517
input10.txt              9             10              0           .431
input11.txt             10             10              0           .427
input12.txt              2             10              0           .426
input13.txt             10             10              0           .439
input14.txt              2             10              0           .437
input15.txt              9             10              0           .441
input16.txt             11             10              0           .446
input17.txt              7             10              0           .438
input18.txt              3             10              0           .450
input19.txt              7             10              0           .437
```

## 1826697
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .665
input01.txt            653             10              0           .664
input02.txt            224             10              0           .476
input03.txt             84             10              0           .439
input04.txt            850             10              0           .797
input05.txt             34             10              0           .435
input06.txt            427             10              0           .503
input07.txt            751             10              0           .715
input08.txt            599             10              0           .611
input09.txt            402             10              0           .520
input10.txt              9             10              0           .421
input11.txt             10             10              0           .439
input12.txt              2             10              0           .437
input13.txt             10             10              0           .435
input14.txt              2             10              0           .437
input15.txt              9             10              0           .435
input16.txt             11             10              0           .440
input17.txt              7             10              0           .435
input18.txt              3             10              0           .437
input19.txt              7             10              0           .493
```

## 1881906
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .733
input01.txt            653             10              0           .660
input02.txt            224             10              0           .469
input03.txt             84             10              0           .468
input04.txt            850             10              0           .814
input05.txt             34             10              0           .455
input06.txt            427             10              0           .521
input07.txt            751             10              0           .781
input08.txt            599             10              0           .615
input09.txt            402             10              0           .521
input10.txt              9             10              0           .436
input11.txt             10             10              0           .436
input12.txt              2             10              0           .416
input13.txt             10             10              0           .432
input14.txt              2             10              0           .414
input15.txt              9             10              0           .439
input16.txt             11             10              0           .436
input17.txt              7             10              0           .435
input18.txt              3             10              0           .420
input19.txt              7             10              0           .433
```

## 1890867
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .690
input01.txt            653             10              0           .650
input02.txt            224             10              0           .481
input03.txt             84             10              0           .464
input04.txt            850             10              0           .823
input05.txt             34             10              0           .437
input06.txt            427             10              0           .547
input07.txt            751             10              0           .727
input08.txt            599             10              0           .600
input09.txt            402             10              0           .524
input10.txt              9             10              0           .438
input11.txt             10             10              0           .456
input12.txt              2             10              0           .420
input13.txt             10             10              0           .431
input14.txt              2             10              0           .417
input15.txt              9             10              0           .444
input16.txt             11             10              0           .451
input17.txt              7             10              0           .424
input18.txt              3             10              0           .435
input19.txt              7             10              0           .445
```

## 1917323
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .691
input01.txt            653             10          1,040           .641
input02.txt            224             10            592           .483
input03.txt             84             10            240           .455
input04.txt            850             10          1,552           .795
input05.txt             34             10             80           .447
input06.txt            427             10            784           .515
input07.txt            751             10          1,168           .722
input08.txt            599             10          1,040           .642
input09.txt            402             10            528           .520
input10.txt              9             10             36           .466
input11.txt             10             10             40           .436
input12.txt              2             10             20           .410
input13.txt             10             10             52           .446
input14.txt              2             10             32           .419
input15.txt              9             10             36           .441
input16.txt             11             10             32           .433
input17.txt              7             10             52           .426
input18.txt              3             10             32           .433
input19.txt              7             10             40           .436
```

## 1917358
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .746
input01.txt            653             10          1,040           .713
input02.txt            224             10            592           .500
input03.txt             84             10            240           .454
input04.txt            850             10          1,552           .877
input05.txt             34             10             80           .450
input06.txt            427             10            784           .543
input07.txt            751             10          1,168           .785
input08.txt            599             10          1,040           .648
input09.txt            402             10            528           .568
input10.txt              9             10             36           .439
input11.txt             10             10             40           .453
input12.txt              2             10             20           .483
input13.txt             10             10             52           .448
input14.txt              2             10             32           .408
input15.txt              9             10             36           .439
input16.txt             11             10             32           .450
input17.txt              7             10             52           .441
input18.txt              3             10             32           .477
input19.txt              7             10             40           .430
```

## 1917366
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .698
input01.txt            653             10          1,040           .649
input02.txt            224             10            592           .468
input03.txt             84             10            240           .460
input04.txt            850             10          1,552           .766
input05.txt             34             10             80           .442
input06.txt            427             10            784           .497
input07.txt            751             10          1,168           .720
input08.txt            599             10          1,040           .613
input09.txt            402             10            528           .507
input10.txt              9             10             36           .439
input11.txt             10             10             40           .465
input12.txt              2             10             20           .430
input13.txt             10             10             52           .432
input14.txt              2             10             32           .414
input15.txt              9             10             36           .472
input16.txt             11             10             32           .435
input17.txt              7             10             52           .445
input18.txt              3             10             32           .418
input19.txt              7             10             40           .440
```

## 1917374
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .740
input01.txt            653             10              0           .662
input02.txt            224             10              0           .508
input03.txt             84             10              0           .453
input04.txt            850             10              0           .827
input05.txt             34             10              0           .444
input06.txt            427             10              0           .528
input07.txt            751             10              0           .765
input08.txt            599             10              0           .623
input09.txt            402             10              0           .562
input10.txt              9             10              0           .454
input11.txt             10             10              0           .440
input12.txt              2             10              0           .402
input13.txt             10             10              0           .456
input14.txt              2             10              0           .426
input15.txt              9             10              0           .443
input16.txt             11             10              0           .434
input17.txt              7             10              0           .434
input18.txt              3             10              0           .437
input19.txt              7             10              0           .437
```

## 1917420
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .678
input01.txt            653             10              0           .686
input02.txt            224             10              0           .491
input03.txt             84             10              0           .476
input04.txt            850             10              0           .760
input05.txt             34             10              0           .444
input06.txt            427             10              0           .514
input07.txt            751             10              0           .709
input08.txt            599             10              0           .643
input09.txt            402             10              0           .551
input10.txt              9             10              0           .439
input11.txt             10             10              0           .430
input12.txt              2             10              0           .433
input13.txt             10             10              0           .447
input14.txt              2             10              0           .429
input15.txt              9             10              0           .443
input16.txt             11             10              0           .452
input17.txt              7             10              0           .440
input18.txt              3             10              0           .453
input19.txt              7             10              0           .461
```

## 1917439
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .686
input01.txt            653             10              0           .637
input02.txt            224             10              0           .526
input03.txt             84             10              0           .476
input04.txt            850             10              0           .890
input05.txt             34             10              0           .496
input06.txt            427             10              0           .611
input07.txt            751             10              0           .727
input08.txt            599             10              0           .637
input09.txt            402             10              0           .557
input10.txt              9             10              0           .429
input11.txt             10             10              0           .456
input12.txt              2             10              0           .449
input13.txt             10             10              0           .453
input14.txt              2             10              0           .435
input15.txt              9             10              0           .445
input16.txt             11             10              0           .461
input17.txt              7             10              0           .455
input18.txt              3             10              0           .481
input19.txt              7             10              0           .441
```

## 1917455
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .712
input01.txt            653             10              0           .664
input02.txt            224             10              0           .483
input03.txt             84             10              0           .457
input04.txt            850             10              0           .829
input05.txt             34             10              0           .451
input06.txt            427             10              0           .544
input07.txt            751             10              0           .733
input08.txt            599             10              0           .625
input09.txt            402             10              0           .534
input10.txt              9             10              0           .436
input11.txt             10             10              0           .445
input12.txt              2             10              0           .417
input13.txt             10             10              0           .436
input14.txt              2             10              0           .404
input15.txt              9             10              0           .441
input16.txt             11             10              0           .441
input17.txt              7             10              0           .444
input18.txt              3             10              0           .429
input19.txt              7             10              0           .432
```

## 1917463
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .706
input01.txt            653             10              0           .660
input02.txt            224             10              0           .474
input03.txt             84             10              0           .468
input04.txt            850             10              0           .823
input05.txt             34             10              0           .430
input06.txt            427             10              0           .534
input07.txt            751             10              0           .764
input08.txt            599             10              0           .616
input09.txt            402             10              0           .524
input10.txt              9             10              0           .435
input11.txt             10             10              0           .436
input12.txt              2             10              0           .419
input13.txt             10             10              0           .425
input14.txt              2             10              0           .417
input15.txt              9             10              0           .436
input16.txt             11             10              0           .441
input17.txt              7             10              0           .426
input18.txt              3             10              0           .429
input19.txt              7             10              0           .439
```

## 1917471
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .700
input01.txt            653             10          1,040           .635
input02.txt            224             10            592           .490
input03.txt             84             10            240           .450
input04.txt            850             10          1,552           .805
input05.txt             34             10             80           .458
input06.txt            427             10            784           .547
input07.txt            751             10          1,168           .741
input08.txt            599             10          1,040           .605
input09.txt            402             10            528           .528
input10.txt              9             10             36           .466
input11.txt             10             10             40           .437
input12.txt              2             10             20           .412
input13.txt             10             10             52           .437
input14.txt              2             10             32           .418
input15.txt              9             10             36           .438
input16.txt             11             10             32           .433
input17.txt              7             10             52           .430
input18.txt              3             10             32           .432
input19.txt              7             10             40           .436
```

## 1920359
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10          1,040           .702
input01.txt            653             10          1,040           .665
input02.txt            224             10            592           .497
input03.txt             84             10            240           .463
input04.txt            850             10          1,552           .784
input05.txt             34             10             80           .455
input06.txt            427             10            784           .540
input07.txt            751             10          1,168           .733
input08.txt            599             10          1,040           .625
input09.txt            402             10            528           .542
input10.txt              9             10             36           .435
input11.txt             10             10             40           .452
input12.txt              2             10             20           .415
input13.txt             10             10             52           .441
input14.txt              2             10             32           .423
input15.txt              9             10             36           .428
input16.txt             11             10             32           .435
input17.txt              7             10             52           .439
input18.txt              3             10             32           .439
input19.txt              7             10             40           .436
```

## 1946145
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .679
input01.txt            653             10              0           .661
input02.txt            224             10              0           .490
input03.txt             84             10              0           .435
input04.txt            850             10              0           .780
input05.txt             34             10              0           .517
input06.txt            427             10              0           .512
input07.txt            751             10              0           .708
input08.txt            599             10              0           .619
input09.txt            402             10              0           .525
input10.txt              9             10              0           .451
input11.txt             10             10              0           .424
input12.txt              2             10              0           .417
input13.txt             10             10              0           .451
input14.txt              2             10              0           .417
input15.txt              9             10              0           .429
input16.txt             11             10              0           .496
input17.txt              7             10              0           .424
input18.txt              3             10              0           .434
input19.txt              7             10              0           .427
```

## 23931913
```
Inputfile            Lines          Score         Leaked        Time(s)
input00.txt            694             10              0           .695
input01.txt            653             10              0           .653
input02.txt            224             10              0           .475
input03.txt             84             10              0           .448
input04.txt            850             10              0           .799
input05.txt             34             10              0           .450
input06.txt            427             10              0           .505
input07.txt            751             10              0           .724
input08.txt            599             10              0           .608
input09.txt            402             10              0           .506
input10.txt              9             10              0           .437
input11.txt             10             10              0           .445
input12.txt              2             10              0           .414
input13.txt             10             10              0           .442
input14.txt              2             10              0           .405
input15.txt              9             10              0           .457
input16.txt             11             10              0           .448
input17.txt              7             10              0           .441
input18.txt              3             10              0           .433
input19.txt              7             10              0           .430
```

