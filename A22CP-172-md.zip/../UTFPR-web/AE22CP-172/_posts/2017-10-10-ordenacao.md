---
layout: post
title: Algoritmos de ordenação
description: 
author: jean
category: 
tags: ordenação
finished: false
date: "2017-10-17 13:50"
---

**Conteúdo**
- Do not remove this line (it will not be displayed)
{:toc}

# Introdução

A ordenação de informação tem impacto relevante em diversos aspectos do nosso cotidiano. Considere, por exemplo, a ordem alfabética em que um dicionário é organizado, ou a ordem crescente (decrescente) em que os preços de um determinado produto são exibidos em uma compra online. Nessas situações, o fato da informação estar organizada (ordenada) de um modo consistente nos permite procurar por determinado item (uma *palavra* nos dicionários, um objeto de determinado *valor* na lista de compras) de forma muito mais simples. 

Do ponto de vista computacional a ordenação de dados tem influência similar. Ao reorganizarmos a informação de forma consistente, diversas operações que poderiam ser feitas sobre o conteúdo armazenado podem, possivelmente, se tornar mais simples e eficientes. 

Em princípio qualquer sequência de dados pode ser ordenada. Para isso, no entanto, é necessário que exista uma [relação de ordem](https://pt.wikipedia.org/wiki/Rela%C3%A7%C3%A3o_de_ordem) para o conjunto dos dados a serem ordenados. Sem perda de generalidade, consideraremos que cada item $i$ na sequência a ser ordenada possui uma chave $k_i\in \mathbb{D}$, tal que essas chaves pertençam a um domínio para o qual exista uma relação de ordem $R \subseteq \mathbb{D}\times \mathbb{D}$. Exemplos de relações de [ordem totais](https://pt.wikipedia.org/wiki/Rela%C3%A7%C3%A3o_de_ordem#Rela.C3.A7.C3.B5es_de_ordem_linear_ou_total) mais comuns são: menor ou igual ($\leq$) e maior ou igual ($\geq$). 

## Ordenação de inteiros

Suponha uma sequência finita de números inteiros dispostos em uma ordem arbitrária, gerado de forma aleatória, por exemplo. Podemos representar essa sequência por:

$$x_1, ~x_2, ~\dots, ~x_n,~\forall x_i\in\mathbb{Z} \mbox{ e } n\in\mathbb{Z}$$

Como o conjunto dos números inteiros $\mathbb{Z}$ é totalmente ordenado de acordo com a relação de ordem $\leq$, existe então uma reordenação dos elementos dessa sequência $\alpha : \mathbb{Z}\to\mathbb{Z}$, tal que:

$$\alpha(1) ~\leq~\alpha(2)~\leq~ \dots ~\leq~\alpha(n)$$

O mesmo é verdade para a relação de ordem $\geq$, e portanto existe também uma reordenação $\beta : \mathbb{Z}\to\mathbb{Z}$

$${\beta(1)} ~\geq~{\beta(2)}~\geq~ \dots ~\geq~{\beta(n)}$$

Transformar uma sequência de dados em ordem arbitrária em uma sequência ordenada é o objetivo dos **algoritmos de ordenação** que veremos a seguir.

## O que são Algoritmos de ordenação?

Um algoritmo de ordenação é um procedimento que recebe como entrada uma sequência de dados, os quais assumiremos como números inteiros daqui em diante, e rearranja os items dessa sequência de modo que ao final eles estejam em uma determinada ordem: crescente, decrescente, por exemplo. 

$$(13, 1, 0 -1, 9, 6, 3, 1) \Rightarrow (-1, 0, 1, 1, 3, 6, 9, 13)$$

# Algoritmos de Ordenação


## Bubble sort

Dada uma sequência de entrada, a *ordenação por bolha* compara pares de itens $x_i$ e $x_{i+1}$, levando para posições posteriores aquele elemento que seja o maior. Na prática isso significa que se $x_{i+1}$ for maior que $x_i$ esses elementos devem trocar de posição:

```cpp
if (x[i] > x[i+1])
    swap(x, i, i+1); // Trocar os elementos nas posições i e i+1
``` 

O Bubble sort percorre do início ao fim do vetor várias vezes, efetuando trocas da forma acima. Na primeira passagem pelo vetor, o maior elemento é levado à posição final $x_{n}$, e, portanto, já estará na posição correta. A próxima iteração levará o segundo maior valor à posição anterior a final $x_{n-1}$ e assim sucessivamente, até que o primeiro elemento seja avaliado. Neste momento, o algoritmo precisa parar pois o vetor estará ordenado e nenhuma troca adicional ocorrerá.

## Selection sort

Dada uma sequência de entrada, a *ordenação por seleção* seleciona a cada passagem pelo vetor o menor elemento e o coloca na posição inicial $x_1$. Na segunda iteração o menor elemento entre $x_2$ e $x_n$ será selecionado e colocado na posição $x_2$. Ou seja, a cada iteração, o algoritmo deixa um elemento a mais na posição correta.  

```cpp
// Trocar os elementos nas posições i e posição do menor elemento de i-n. 
swap(x, i, min(x, i, n)); 
``` 

## Insertion sort

Dada uma sequência de entrada, a *ordenação por inserção* percorre a sequência e para cada valor em uma determinada posição $i$, reinsere o valor $x_i$ na sua posição correta no momento. A posição correta $j$ para um elemento qualquer $x_i$ em um dado momento é aquela posição tal que $x_{j} \leq x_i \leq x_{j+1}$. 

## Quicksort

Consideremos uma sequência numérica qualquer de tamanho $n$, em ordem arbitrária.

$$x_1, ~x_2, ~\dots, ~x_n,~\forall x_i\in\mathbb{Z} \mbox{ e } n\in\mathbb{Z}$$

Vamos analisar as propriedades produzidas pelo seguinte procedimento, o qual é mais simples que a ordenação em si. 

Dado qualquer elemento desta sequência $x_p$, o qual chamaremos *pivô*, **reordene a sequência** de modo que $\forall x_i$ que preceda $x_p$, $x_i\leq x_p$. Em contrapartida, $\forall x_j$ que suceda $x_p$, $x_p \leq x_j$. Observe que não estamos exigindo que os elementos anteriores ou posteriores a $x_p$ estejam ordenados. No entanto, uma propriedade importante é evidente.

  - Se todos antes de $x_p$ são menores ou iguais a ele e todos elementos depois são maiores ou iguais, então $x_p$ está na sua posição correta. Ou seja, na posição que ele ocuparia em uma sequência ordenada.

Por essa propriedade concluímos que $x_p$ não precisa mais ser comparado a nenhum outro elemento. Nos restando duas subpsequências a serem ordenadas. Aquela contendo os elementos anteriores e aquela contendo os elementos posteriores a $x_p$.

$$[\dots],~ x_p,~ [\dots]$$

Podemos então repetir o mesmo procedimento em cada uma dessas subsequências, até que todos elementos tenham sido considerados como pivô e, portanto, colocados em suas devidas posições ordenadas.

O Algoritmo acima descrito é chamado, no contexto do *Quicksort*, de  *partition*.


### Partition

Dada uma sequência númerica em ordem arbitrária como entrada e um valor *pivô* $k$.

$$x_1, ~x_2, ~\dots, ~x_n,~\forall x_i\in\mathbb{Z} \mbox{ e } n\in\mathbb{Z}$$

*Partition* irá produzir uma nova sequência, com o pivô numa posição $p$, de modo que $y_i \leq k$, $\forall i \leq p$ e $y_j \geq k$, $\forall j \geq p$.

$$y_1,~y_2,~\dots,y_{p-1},~ k_p,~ y_{p+1}, \dots,~ y_{n-1},~ y_{n}$$

Outra característica importante dessa nova sequência é que todos elementos $y_1,\dots,y_{p-1}$ são menores que aqueles em $y_{p+1},\dots,y_n$. Portanto, eles não precisam mais ser comparados. As comparações adicionais acontecerão internamente a cada uma das sequências apenas.


```cpp
// Versão Cormen (Lomuto)
int partition(Type* A, int p, int r) {
    Type x = A[r];
    int i  = p - 1;    
    for (int j = p; j < r; j++) {
        if (A[j] <= x) {
            i = i + 1;
            swap(A, i, j);
        }
    }
    swap(A, i + 1, r);
    return i + 1;
}
```

```cpp
// Versao simples (Hoare)
int partition(Type* A, int p, int r) {
    Type x = A[r];
    int i = p;
    int j = r; 
    while (i < j) {
        while (A[i] <= x && i < r)
            i++;
        while (A[j] > x)
            j--;
            
        if (i < j) 
            swap(A, i, j);
    }
    A[p] = A[j];
    A[r] = x;
    return r;
}
```

  - Partition
  - Complexidade no melhor caso
  - O que afeta o melhor caso
  - Complexidade no pior caso
  - Como contornar o pior caso: escolha do pivô
  - Mediana de três: p, r, (p+r)/2
  
  -Insertionsort
  -Heapsort
  -Shellsort
  -Mergesort

