---
layout: post
title: Exercícios (Pilhas)
description:  Introduz a estrutura de dados Pilha, a qual consiste de operações push, pop e top, implementadas sobre uma lista duplamente encadeada. O problema da validação de parênteses é utilizado didaticamente.
author: Jean P. Martins
category: 
tags: pilhas-filas
finished: false
date: "2017-09-07 18:40"
---


**Conteúdo**
* Do not remove this line (it will not be displayed)
{:toc}


# Exercícios

## Validação parentética

Agora que defimos uma pilha e indicamos as operações que podem ser executadas sobre ela, vejamos como podemos usar a pilha na solução de problemas. Examine uma expressão matemática que inclui vários conjuntos de parênteses agrupados. Por exemplo:

$$7 - ((X *((X+ Y)/ (J-3)) + Y)/(4-2.5))$$
 
Queremos garantir que os parênteses estejam corretamente agrupados, ou seja, desejamos verificar se:

1. Existe um número igual de parênteses esquerdos e direitos.
2. Todo parêntese da direita está precedido por um parêntese da esquerda.

```cpp
#include "stack.h"
// Funções auxiliares para identificar o caractere sendo lido. 
// [!] É necessário implementá-las para que o exemplo funcione. 
bool abreEscopo(char c);
bool fechaEscopo(char c);
bool escopoCorreto(char a, char b);
int verificaExpressao(const char* expressao, int esize) {
	stack* p = new_stack();	
	for (int i = 0; i < esize; ++i) {
		char atual = expressao[i];
		if ( abreEscopo(atual) ) {
			stack_push(p, atual);
		} else if ( fechaEscopo(atual) ) {
			if (stack_empty(p)) return i;
			if ( !escopoCorreto(stack_pop(p), atual) ) return i;
		}
	}	
	if (!stack_empty(p)) return esize;
	free_stack(p);
	return esize+1;
}
```

## Validação de expressões
Adapte o código do validador para que funcione com expressões mais complexas, contendo os demais delimitadores

$$(, ), [, ] , \{, \}$$

## Verificação de palíndromo

Escreva um algoritmo para determinar se uma string de caracteres de entrada é da forma:

$$x C y$$

onde $$x,y$$ são strings e $$y$$ é o inverso de $$x$$. O caractere $$C$$ delimita o fim de $$x$$. Somente um caractere da string pode ser lido de cada vez.



## Verificar concatenação de palíndromos

Escreva um algoritmo para determinar se uma string de caracteres de entrada é da forma:

$$a D b D c D \dots D z$$

onde cada string $$a, b, c,\dots,z$$, é da forma da string definida no exercício anterior, isto é, $$a = xCy$$

## Underflow
Que conjunto de critérios é necessário e suficiente para que uma sequência de operações `push` e `pop` sobre uma única pilha (inicialmente vazia) deixe a pilha vazia e não provoque *underflow*?

# Referências -pdf
[![livro](../assets/tenenbaum-book.jpg)](http://www.san.uri.br/~ober/arquivos/disciplinas/estruturaII_SI/(ebook)Estruturas%20de%20Dados%20Usando%20C%20(Tenenbaum).pdf)
 
