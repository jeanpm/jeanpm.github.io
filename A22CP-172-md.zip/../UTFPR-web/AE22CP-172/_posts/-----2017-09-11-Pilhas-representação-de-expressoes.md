---
layout: post
title: Pilhas - Representações prefixa e posfixa
description: 
author: Jean P. Martins
category:
tags: pilhas
finished: false
date: "2017-09-11 18:40"
---


**Conteúdo**
* Do not remove this line (it will not be displayed)
{:toc}

# Introdução

Considere a soma de A mais B, numa expressão $A+B$. Neste exemplo, $+$ é um operador sendo aplicado aos operandos $A,B$. Este tipo de representação para a expressão de soma dos dois operandos é chamada **infixa**, pois o operador se posiciona entre os operandos.

Considerando-se o posicionamento do operador, no entando, existem duas representações alternativas: **prefixa** e **posfixa**.

  * +AB (prefixa)
  *  AB+ (posfixa)
  
## Input Format
Uma string contendo operandos (dígitos 0-9) e operandos (+,-,/,^,*) na forma posfixa. O operador `exponenciação` é indicado pelo caracter '^', e pode ser implementado pela função:

```cpp
#include <math.h>
// Exponenciação, é representada por AB^ (posfixa) => A^B (infixa) 
double r = pow(A, B);
```

A string pode conter espaços, os quais devem ser ignorados. As seguintes funções podem ser utilizadas para verificar o tipo de um caracter char c.



## Motivação
Como poderá ser notado, notações prefixa e posfixa removem a ambiguidade de uma expressão, desta forma, parenteses não são mais necessários. 

## Notação préfixa
Para compreendermos a utilidade das notações prefixa e posfixa, consideremos as demais operações definidas como funções:

```cpp
int add(int A, int B);
int mult(int A, int B);
int div(int A, int B);	
```

Dada uma expressão de exemplo, definida como:

$$(A + B/C) * D$$

Ela seria implementada em uma chamada da seguinte forma:

```cpp
mult(add(A, div(B,C)),D);
``` 

O que utilizando a notação prefixa em termos de $$+,*,/$$, avalia-se a expressão acima, considerando-se as operações que serão efetuadas em primeiro lugar, ou seja, neste caso: 

  1. divisão $$\rightarrow /BC$$, 
  2. adição $$\rightarrow +A/BC$$, 
  3. multiplicação $$\rightarrow *+A/BCD$$.

$$*+A/BCD$$

Para comprovarmos se essa expressão se equivale à forma infixa, performe as operações assim que dois operandos estiverem disponíveis, iniciando a avaliação da esquerda para a direita.


Ao compararmos as duas representações para a expressão, o que é visivelmente notável?

$$ (A + B/C) * D $$

$$*+A/BCD$$

**Parenteses se tornam desnecessários!** Como consequência, avaliar o resultado de uma expressão se torna muito mais simples. De fato pode ser implementado lendo-se a expressão apenas uma vez.

## Notação pósfixa

Tanto na notação préfixa quanto na pósfixa, é importante lembrar que os operadores com precedência devem ser avaliados/convertidos primeiro, a não ser que uma possível parentização altere a ordem de precedência.

No exemplo anterior $$(A+B/C) * D$$, a multiplicação é efetuado somente ao final, devido à parentização. A ausência de parênteses, nesse exemplo, nos permitiria outras interpretações: 

$$ A + ((B/C) * D)$$
  
$$ A + (B / (C*D))$$
  
A forma pósfixa é a contrapartida da prefixa, em que os operadores são posicionados após os operandos. Retornando ao exemplo original $$(A+B/C)*D$$, temos que a divisão $$B/C$$ deve ser convertida em primeiro lugar:

$$(A + BC/) * D$$

Em seguida a adição entre parênteses

$$(ABC/+) * D $$
  
Por fim, a multiplicação

$$ ABC/+D*$$


## Utilidade

Dada a expressão em forma infixa, elabore um algoritmo que dê o resultado da expressão em apenas uma leitura da string:

$$(A + B/C) * D$$
	  
Dada a expressão em forma pósfixa, elabore um  algoritmo que dê o resultado da expressão em apenas uma leitura da string:

$$ABC/+D*$$
	  
## Conversão infixa/pósfixa

| **Forma infixa** | **Forma pósfixa** |
| A+ B | AB+ | 
|A+B-C |AB+C-|
| (A+B) * C | AB+C* |
| A+(B*C) | ABC*+|
|(A+B)*(C-D)| AB+CD-* |


	  
# Avaliação de expressão pósfixa

{% highlight cpp %}
#include "stack.h"
#include <stdio.h>
#include <ctype.h>
#include <math.h>
/*
 Dado um caractere representando um operador qualquer, retorna-se o 
 resultado da operação c(a,b)
*/
double operacao(char c, double a, double b) {
    switch (c) {
        case '+' : return a + b;
        case '-' : return a - b;
        case '*' : return a * b;
        case '/' : return a / b;
        case '^' : return pow(a, b); // Exponenciação
    }
    return a;
}
/**
 Avalia uma expressão pósfixa. Nenhuma verificação sintática é feita 
 na expressão, portanto, expressões inválidas podem levar a
 comportamento inesperado da função.
*/
double evalpos(const char* e) {
	// Estrutura de dados  pilha da STL de c++
	// Armazena valores `double`
	stack* p = new_stack();	
	int i = 0;	
	char c = ' ';
	while (e[i] != '\0') {
		c = e[i++];	
		if (isdigit(c)) 
		{// Se o caractere atual é um operando, um dígito (0-9)
			// Insere-se o mesmo na pilha
			stack_push(p, (double) c - '0');
		} else {// Se e[i] não é um operando, ele deveria ser um operador. 
			// Neste caso, desempilha-se dois operandos da pilha.
			// Obs: o segundo será o primeiro operando
			double b = stack_pop(p); 
			double a = stack_pop(p);
			// Efetua-se a operação determinada por e[i]
			a = operacao(c, a, b);
			// Insere o resultado novamente na pilha.
			stack_push(p, a);
		}
	}	
	// O resultado estará no topo da pilha, retorne-o.
	double result = stack_pop(p); 
	free_stack(p);
	return result;
}
{% endhighlight cpp %}
