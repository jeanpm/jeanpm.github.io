---
layout: post
title: Lógica de predicados - Identidade
description: 
author: jean
category: 
tags: predicados
finished: false
date: "2017-10-26 10:20"
---

**Conteúdo**
- Do not remove
{:toc}

# Identidades

Na lógica de predicados podemos definir um predicado $I(x,y)$ para denotar a igualdade entre $x$ e $y$.
  - $I(x,y)$: $x$ igual a $y$

No entanto, por esse predicado ser de uso bastante comum, se torna às vezes conveniente representá-lo de forma mais compacta. O mesmo aconteceria se quiséssemos definir um predicado $M(x,y)$ para denotar $x$ é menor que $y$. Como tais predicados são comumente representado pelos símbolos $=$ e $<$ não há motivos para que não utilizemos os mesmos símbolos também na linguagem da lógica de predicados. 

Enquanto a letra 'I' pode ser utilizada para denotar o predicado de igualdade/identidade, ou seja $I(x,y)$ indicando a igualdade entre $x$ e $y$; ela também poderia ser utilizada em outras situações para denotar outro predicado qualquer, exemplo $I(x)$ indicando que $x$ é impar. Por outro lado, o símbolo '=' também representa o predicado identidade, no entanto, ele nunca assumirá um significado diferente, ou seja, é um símbolo específico para representar o predicado de igualdade.
  - $x=y$: $x$ igual a $y$
  
Diferentemente dos demais predicados, $=$ é utilizado na forma infixa, ou seja, entre os operandos. Isso facilita pois mantém a forma de representação convencionalmente utilizada nas demais áreas da matemática.

## Exemplos

Formalize as seguintes sentenças utilizando o predicado identidade '$=$'

  - $a$: Álvaro de Campos
  - $t$: Tabacaria
  - $f$: Fernando Pessoa
  - $A(x)$: $x$ é um autor português
  - $M(x,y)$: $x$ é melhor autor que $y$
  - $E(x,y)$: $x$ escreveu $y$
  
a. Fernando Pessoa não é Álvaro de Campos

b. Existe Fernando Pessoa  

c. Se Fernando Pessoa é Álvaro de Campos, então Álvaro de Campos escreveu Tabacaria

d. Somente Fernando Pessoa escreveu Tabacaria

e. Fernando Pessoa é o melhor autor português

f. Existem ao menos duas coisas diferentes.

g. Existe somente uma coisa.

h. Existem exatamente duas coisas.

## Introdução da identidade

Para qualquer letra nominal $\alpha$, podemos sempre introduzir a identidade $\alpha = \alpha$. Esse tipo de regra é útil para produzir exemplos para outras regras de derivação. Considere, por exemplo, a introdução dos quantificadores universal e existencial, a introdução de ambos depende da existência de um exemplo.

Para o quantificador universal, esse exemplo deve utilizar uma letra nominal genérica, de modo que seja possível generalizar a afirmação. Nesse caso, uma instância/exemplo $Fa\land Ga$ pode ser generalizada à $\forall x (Fx \land Gx)$, desde que não haja restrições quanto à letra $a$. 

Para o quantificador existencial, por outro lado, o funcionamento é mais simples. Se tivermos um exemplo, então podemos generalizá-lo. Deste modo, a partir de $(Fa\land Ga)$ podemos imediatamente concluir $\exists x(Fx \land Gx)$. 

### Exemplos

Dada a interpretação acima, como demonstraríamos os seguintes argumentos?

$$\vdash \forall x (x=x)$$

$$\vdash \exists x (a=x)$$

## Eliminação da identidade

A regra de eliminação da identidade é apenas uma formalização da nossa intuição. Se duas coisas são iguais, posso utilizar tanto uma quanto a outra em qualquer situação. 

$$Fa, a=b \vdash Fb$$

$$Fa, \neg Fb \vdash \neg (a = b)$$

$$\vdash \forall x \forall y (x=y)\to(y=x)$$ 

$$\vdash \forall x \forall y \forall z (x=y\land y=z)\to (x=z))$$
