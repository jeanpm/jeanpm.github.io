---
layout: post
title: Lógica de predicados - Informal  
description: 
author: jean
category: 
tags: predicados
finished: false
date: "2017-09-27 10:20"
---

**Conteúdo**
- Do not remove
{:toc}

# A necessidade de uma linguagem mais rica

Até então desenvolvemos a lógica proposicional, examinando-a de três ângulos: sua teoria de demonstração (dedução natural), sua sintaxe (árvores das fórmulas) e sua semântica (tabelas-verdade). Toda essa discussão se inicou com *frases declarativas*, ou *proposições*, as quais sempre é possível atribuir um valor lógico. A linguagem da lógica proposicional, por outro lado, é limitada, e existem tipos de afirmações que nela não podem ser representadas satisfatoriamente.

Vejamos, por exemplo, a frase declarativa:

  + "Todo estudante é mais jovem do que algum instrutor."

É fácil perceber que esta sentença não faz uso de nenhum dos conectivos da lógica proposicional: *não*, *e*, *ou*, *se... então*. Deste modo, o máximo que poderíamos fazer, seria representá-la como uma proposição atômica $p$

  + $p$: "Todo estudante é mais jovem do que algum instrutor."

Obviamente, isto não nos traria nenhuma informação sobre a estrutura da frase. 

No contexto dessas limitações, a *lógica de predicados*, ou *lógica de segunda ordem*, é proposta como forma de representar modificadores do tipo 

  + *existe*, 
  + *todo*, 
  + *entre* e 
  + *apenas*. 
  
## Predicados

Na frase acima, podemos identificar algumas propriedades

  + *ser um estudante*
  + *ser um instrutor*
  + *ser mais jovem do que alguém*

Gostaríamos de algum mecanismo por meio do qual pudéssemos representá-las, juntamente com suas relações lógicas e dependências.


Tomemos como exemplo *ser um estudante*, podemos definir que essa propriedade como um *predicado* $E(\cdot)$, o qual quando aplicado a algo nos diz que esse algo é um estudante.

  + $E($André$)$: nos diz que *André* é um estudante.
  
Seguindo a mesma idéia, podemos definir predicados para as demais propriedades

  + $I($Paulo$)$: *Paulo* é um instrutor.
  + $J($André, Paulo$)$: *André* é mais jovem do que *Paulo*.

Nestes exemplos, $E,I,J$ são chamados **predicados**.

[**pre·di·ca·do**](http://michaelis.uol.com.br/moderno-portugues/busca/portugues-brasileiro/predicado/)
  1. Atributo de um ser; característica, propriedade, qualidade.
  2. Qualidade considerada positiva ou desejável, como bondade, delicadeza, gentileza etc.; mérito, virtude: Encontrou uma pessoa com muitos predicados.
  3. GRAM Tudo aquilo que se diz do sujeito da frase: Pedro vendeu o carro (vendeu o carro, o predicado, representa aquilo que se declara a respeito de Pedro, o sujeito).
  4. LÓG Numa proposição ou num juízo, atributo de um sujeito, que pode ser afirmado ou negado. Símbolo P.
  
## Variáveis

Os predicados acima nos permitem definir propriedades, as quais podem ser utilizadas para identificar *estudantes*, *instrutores* e a relação de *juventude* entre um estudante e um instrutor. No entanto, ainda não é viável representar todos estudantes

  + "**Todo estudante** é mais jovem do que algum instrutor."

Sem que para isso tenhamos que defini-los um a um.

  + $E($André$)$, $E($Pedro$)$, $E($Maria$)$, $E($Joana$)$, etc..

Claramente isto se torna inviável para qualquer número razoável de alunos, e portanto não é uma bom mecanismo para representar "**Todo estudante...**"

Para contornarmos esse problema, utilizaremos o conceito de *variável*. Uma variável $u,v,w,x,y,z,\dots$ nada mais é que um substituto para  valores concretos. Utilizando $x,y$, poderíamos formalizar os predicados anteriores.

  + $E(x)$: $x$ é um estudante.
  + $I(x)$: $x$ é um instrutor.
  + $J(x,y)$: $x$ é mais jovem do que $y$.
  
## Quantificadores

As váriaveis nos oferecem a formalização necessária, porém ainda não nos permite especificar que um *predicado* se aplica a **todo** ou **algum**. Para isso, utilizamos os **quantificadores**, os quais definem o escopo das variáveis. 

  + $\forall$: "para todo"
  + $\exists$: "existe" ou "algum"

Os quantificadores em conjunto com variáveis nos permitem então definir afirmações sobre algo genérico

  + $\forall y$: "para todo $y$
  + $\exists z$: "existe $z$" ou "existe algum $z$"
  
Portanto, se quero dizer que todo $x$ é estudante, utilizo o quantificador $\forall$ em conjunto com o predicado e a variável $x$.

$$\forall x E(x)$$


Retornando à frase original

  + "Todo estudante é mais jovem do que algum instrutor."

Podemos reescrevê-la, de forma a tornar mais óbvia as relações.

  + "Se $x$ é um estudante, então existe um instrutor $y$, tal que $x$ é mais jovem do que $y$."
  
Devemos, no entanto, observar que a segunda frase se aplica a apenas um estudante $x$, como queremos generalizar a todos estudantes, utilizaremos o quantificador $\forall$

$$\forall x(\dots)$$

A parte interna dos parênteses é um condicional que se aplica a todo estudante, e portanto

$$\forall x(E(x)\to \dots)$$

O consequente deste condicional se refere ao trecho:

  + "existe um instrutor $y$, tal que $x$ é mais jovem do que $y$."
  + "existe $y$, tal que $y$ é um instrutor e $x$ é mais jovem do que $y$."
  
Que pode ser representado por:

$$\exists y (I(y) \land J(x,y))$$

Por fim, a estrutura da frase exemplo pode ser escrita de maneira simbólica da seguinte forma

$$\forall x(E(x)\to \exists y (I(y) \land J(x,y)))$$

A qual pode ser lida da seguinte forma:

  + "Para todo $x$, se $x$ é um estudante, então existe algum $y$ que é um instrutor tal que $x$ é mais novo do que $y$"
  
### Exemplo

Considere os seguintes predicados:

  + $A(x)$: $x$ é uma ave
  + $V(x)$: $x$ pode voar
  
Represente simbolicamente a frase

  + "Nem todas as aves podem voar"
$$\neg(\forall x (A(x)\to V(x)))$$
  
  + "Existem aves que não voam"
$$\exists x(A(x)\land \neg V(x))$$

## Símbolos funcionais

A lógica de predicados estende a lógica proposicional não só quanto aos quantificadores, mas também com o conceito de *símbolo funcional*. Um símbolo funcional nada mais é que uma função, a qual, dada uma variável, retorna alguma informação não ambígua sobre a variável em questão. Por exemplo, consideremos a sentenças

  "Toda criança é mais jovem do que sua mãe".
  
Ela pode ser representada simbolicamente utilizando os predicados:

  + $C(x)$: $x$ é uma criança
  + $M(x,y)$: $x$ é mãe de $y$
  + $J(x,y)$: $x$ é mais jovem que $y$
  
$$\forall x \forall y(C(x) \land M(y,x) \to J(x,y))$$

Não há nada errado com esta fórmula, no entanto ela poderia ser simplificada por meio do uso de um símbolo funcional que retornasse a mãe de $x$.

  + $m(x)$: retorna a mãe de $x$
  
$$\forall x (C(x) \to J(x, m(x)))$$

Símbolos funcionais também podem ser binários, terciários e assim por diante: 

  + $g(x,y)$: nota do aluno $x$ na disciplina $y$
  
No caso especial em que nenhuma variável é necessária o simbolo funcional representa uma constante.

  + $m$: é uma constante para indicar Márcia
  
### Exemplo
Utilizando o predicado $M(x,y)$: $x$ é mãe de $y$, considere a simbolização da frase:

"André e Paulo têm a mesma avó materna"

1. Reescreva de forma simbólica utilizando somente predicados.  

2. Reescreva de forma simbólica utilizando predicados e símbolos funcionais.

OBS: Utilize o símbolo de igualdade $=$ se necessário.

### Exemplo

Considere a simbolização da frase:

"Todo filho de meu pai é meu irmão"

1. Reescreva de forma simbólica utilizando somente predicados.  

2. Reescreva de forma simbólica utilizando predicados e símbolos funcionais.
  
# Referências

Seção 2.1: Pg. 71, [Logica - Huth & Ryan (PDF).](http://www.cse.chalmers.se/edu/course/DAT060/huthryan_lics2_sol.pdf)
