---
layout: post
title: Lógica de predicados - Informal  
description: 
author: jean
category: 
tags: predicados
finished: false
date: "2017-09-27 10:20"
---

**Conteúdo**
- Do not remove
{:toc}

# A necessidade de uma linguagem mais rica

Até então desenvolvemos a lógica proposicional, examinando-a de três ângulos: sua teoria de demonstração (dedução natural), sua sintaxe (árvores das fórmulas) e sua semântica (tabelas-verdade). Toda essa discussão se inicou com *frases declarativas*, ou *proposições*, as quais sempre é possível atribuir um valor lógico. A linguagem da lógica proposicional, por outro lado, é limitada, e existem tipos de afirmações que nela não podem ser representadas satisfatoriamente.

Vejamos, por exemplo, a frase declarativa:

  + "Todo estudante é mais jovem do que algum instrutor."

É fácil perceber que esta sentença não faz uso de nenhum dos conectivos da lógica proposicional: *não*, *e*, *ou*, *se... então*. Deste modo, o máximo que poderíamos fazer, seria representá-la como uma proposição atômica $p$

  + $p$: "Todo estudante é mais jovem do que algum instrutor."

Obviamente, isto não nos traria nenhuma informação sobre a estrutura da frase. 

No contexto dessas limitações, a *lógica de predicados*, ou *lógica de segunda ordem*, é proposta como forma de representar modificadores do tipo 

  + *existe*, 
  + *todo*, 
  + *entre* e 
  + *apenas*. 
  
## Predicados

Na frase acima, podemos identificar algumas propriedades

  + *ser um estudante*
  + *ser um instrutor*
  + *ser mais jovem do que alguém*

Gostaríamos de algum mecanismo por meio do qual pudéssemos representá-las, juntamente com suas relações lógicas e dependências.


Tomemos como exemplo *ser um estudante*, podemos definir que essa propriedade como um *predicado* $E(\cdot)$, o qual quando aplicado a algo nos diz que esse algo é um estudante.

  + $E($André$)$: nos diz que *André* é um estudante.
  
Seguindo a mesma idéia, podemos definir predicados para as demais propriedades

  + $I($Paulo$)$: *Paulo* é um instrutor.
  + $J($André, Paulo$)$: *André* é mais jovem do que *Paulo*.

Nestes exemplos, $E,I,J$ são chamados **predicados**.

[**pre·di·ca·do**](http://michaelis.uol.com.br/moderno-portugues/busca/portugues-brasileiro/predicado/)
  1. Atributo de um ser; característica, propriedade, qualidade.
  2. Qualidade considerada positiva ou desejável, como bondade, delicadeza, gentileza etc.; mérito, virtude: Encontrou uma pessoa com muitos predicados.
  3. GRAM Tudo aquilo que se diz do sujeito da frase: Pedro vendeu o carro (vendeu o carro, o predicado, representa aquilo que se declara a respeito de Pedro, o sujeito).
  4. LÓG Numa proposição ou num juízo, atributo de um sujeito, que pode ser afirmado ou negado. Símbolo P.
  
## Variáveis

Os predicados acima nos permitem definir propriedades, as quais podem ser utilizadas para identificar *estudantes*, *instrutores* e a relação de *juventude* entre um estudante e um instrutor. No entanto, ainda não é viável representar todos estudantes

  + "**Todo estudante** é mais jovem do que algum instrutor."

Sem que para isso tenhamos que defini-los um a um.

  + $E($André$)$, $E($Pedro$)$, $E($Maria$)$, $E($Joana$)$, etc..

Claramente isto se torna inviável para qualquer número razoável de alunos, e portanto não é uma bom mecanismo para representar "**Todo estudante...**"

Para contornarmos esse problema, utilizaremos o conceito de *variável*. Uma variável $u,v,w,x,y,z,\dots$ nada mais é que um substituto para  valores concretos. Utilizando $x,y$, poderíamos formalizar os predicados anteriores.

  + $E(x)$: $x$ é um estudante.
  + $I(x)$: $x$ é um instrutor.
  + $J(x,y)$: $x$ é mais jovem do que $y$.
  
## Quantificadores

As váriaveis nos oferecem a formalização necessária, porém ainda não nos permite especificar que um *predicado* se aplica a **todo** ou **algum**. Para isso, utilizamos os **quantificadores**, os quais definem o escopo das variáveis. 

  + $\forall$: "para todo"
  + $\exists$: "existe" ou "algum"

Os quantificadores em conjunto com variáveis nos permitem então definir afirmações sobre algo genérico

  + $\forall y$: "para todo $y$
  + $\exists z$: "existe $z$" ou "existe algum $z$"
  
Portanto, se quero dizer que todo $x$ é estudante, utilizo o quantificador $\forall$ em conjunto com o predicado e a variável $x$.

$$\forall x E(x)$$


Retornando à frase original

  + "Todo estudante é mais jovem do que algum instrutor."

Podemos reescrevê-la, de forma a tornar mais óbvia as relações.

  + "Se $x$ é um estudante, então existe um instrutor $y$, tal que $x$ é mais jovem do que $y$."
  
Devemos, no entanto, observar que a segunda frase se aplica a apenas um estudante $x$, como queremos generalizar a todos estudantes, utilizaremos o quantificador $\forall$

$$\forall x(\dots)$$

A parte interna dos parênteses é um condicional que se aplica a todo estudante, e portanto

$$\forall x(E(x)\to \dots)$$

O consequente deste condicional se refere ao trecho:

  + "existe um instrutor $y$, tal que $x$ é mais jovem do que $y$."
  + "existe $y$, tal que $y$ é um instrutor e $x$ é mais jovem do que $y$."
  
Que pode ser representado por:

$$\exists y (I(y) \land J(x,y))$$

Por fim, a estrutura da frase exemplo pode ser escrita de maneira simbólica da seguinte forma

$$\forall x(E(x)\to \exists y (I(y) \land J(x,y)))$$

A qual pode ser lida da seguinte forma:

  + "Para todo $x$, se $x$ é um estudante, então existe algum $y$ que é um instrutor tal que $x$ é mais novo do que $y$"
  
### Exemplo

Considere os seguintes predicados:

  + $A(x)$: $x$ é uma ave
  + $V(x)$: $x$ pode voar
  
Represente simbolicamente a frase

  + "Nem todas as aves podem voar"
$$\neg(\forall x (A(x)\to V(x)))$$
  
  + "Existem aves que não voam"
$$\exists x(A(x)\land \neg V(x))$$

# Exercícios

## #0

Interpretando como 

  + $c$: "está chovendo"
  + $R$: "é uma rã"
  + $V$: "é verde"
  + $S$: "é saltitante"
  + $I$: "é iridescente"
  
Formalize as seguintes sentenças:

  a. Todas as rãs são verdes
  
  b. Nenhuma rã é verdes
  
  c. Algumas rãs são verdes
  
  d. Algumas rãs não são verdes
  
  e. Toda coisa é uma rã.
  
  f. Alguma coisa é uma rã.
  
  g. Nem toda coisa é uma rã.
  
  h. Nada é uma rã.
  
  i. Existem rãs verdes
  
  j. Qualquer coisa ou é rã ou é iridescente.
  
  k. Qualquer coisa é uma rã verde.
  
  l. Está chovendo e algumas rãs estão saltitando
  
  m. Se está chovendo, então todas as rãs estão saltitando
  
  n. Algumas coisas são verdes e algumas não são
  
  o. Algumas coisas são verdes e iridescentes simultaneamente
  
  p. Ou qualquer coisa é uma rã, ou nada é uma rã
  
  q. Qualquer coisa ou é uma rã ou não é uma rã.
  
  r. Todas as rãs são rãs.
  
  s. Somente rãs são verdes.
  
  t. Não existem rãs iridescentes.
  
  u. Todas as rãs verdes estão saltitando
  
  v. Algumas rãs verdes não estão saltitando
  
  w. Não é verdade que algumas rãs verdes estão saltitando.
  
  x. Se nada é verde, então não existem rãs verdes.
  
  y. Rãs verdes saltam se e somente se não está chovendo. 

## #1

Use os predicados

  + $A(x,y)$: $x$ admira $y$
  + $B(x,y)$: $x$ estava presente em $y$
  + $P(x)$: $x$ é um professor
  + $E(x)$: $x$ é um estudante
  + $L(x)$: $x$ é uma aula
  
e o símbolo funcional (constante)

  + $m$: Maria
  
  a. Maria admira todo professor
  
  b. Algum professor admira Maria
  
  c. Maria admira a si própria
  
  d. Nenhum estudante estava presente em todas as aulas.
  
  e. Nenhuma aula teve a presença de todos os estudantes
  
  f. Nenhuma aula teve a presença de qualquer estudante.


## #2
Suponha 
  + $F(x,y)$: $x$ é o pai de $y$
  + $M(x,y)$: $x$ é a mãe de $y$
  + $H(x,y)$: $x$ é marido de $y$
  + $S(x,y)$: $x$ é irmã de $y$
  + $B(x,y)$: $x$ é irmão de $y$
  
É permitido usar constantes para representar nomes: 'Ed', 'Patsy'

  a. Todos têm uma mãe
  
  b. Todos têm um pai e uma mãe
  
  c. Todos que tem uma mãe tem um pai
  
  d. Ed é um avô
  
  e. Todos os pais são pais ou mães
  
  f. Todos os maridos são cônjuges
  
  g. Nenhum tio é tia
  
  h. Todos os irmãos são irmãos ou irmãs
  
  i. Nenhuma avó é pai de alguém
  
  j. Ed e Patsy são marido e mulher
  
  k. Carlos é cunhado de Monique.

# Referências

Seção 1.3: Pgs. 25-28, [Logica - Huth & Ryan (PDF).](http://www.cse.chalmers.se/edu/course/DAT060/huthryan_lics2_sol.pdf)
