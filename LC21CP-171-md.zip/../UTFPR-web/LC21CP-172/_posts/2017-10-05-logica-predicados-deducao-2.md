---
layout: post
title: Lógica de predicados - Regras de dedução II
description: 
author: jean
category: 
tags: predicados
finished: false
date: "2017-10-04 10:20"
---

**Conteúdo**
- Do not remove
{:toc}


## Quantificador existencial

Assim como todos os demais operadores o quantificador existencial ($\exists$) também possui duas regras de inferência: introdução e eliminação. 

### Regra de introdução

A regra de introdução do quantificador existencial segue de forma intuitiva e direta a partir de sua definição. Suponhamos, por exemplo, o caso específico $F(a)\land G(a)$. Por si só, este exemplo já nos permite concluir a forma mais geral $\exists x (Fx \land Gx)$, nesta situação $a$ serviu como prova da existência de um determinado $x$ para o qual $Fx \land Gx$ fosse verdadeira.


#### Exemplo 1

$$\forall x (Fx \lor Gx) \vdash \exists x(Fx \lor Gx)$$

$$
\begin{array}{llr}
1 & \forall x (Fx \lor Gx) & \mbox{premissa}\\
2 & Fa \lor Ga       & \mbox{e-}\forall 1 \\
3 & \exists x (Fx \lor Gx) & \mbox{Introdução do existencial em 2}
\end{array}
$$


#### Exemplo 2

$$\forall x (Fx \lor Gx) \vdash \exists x Fx \lor \exists x Gx$$

Apesar da similaridade como exemplo anterior, a demonstração neste caso é um pouco mais complexa. Precisamos provar que é possível derivar a conclusão a partir de cada disjuncto, utilizando a regra de eliminação da disjunção. 

$$ \dfrac{\phi\quad\psi\quad (\phi\to\chi) \quad (\psi\to\chi)}{\chi}$$

$$
\begin{array}{llr}
1 & \forall x (Fx \lor Gx) & \mbox{premissa}\\
2 & Fa \lor Ga       & \mbox{e-}\forall 1 \\
3.1 & \qquad Fa  & \mbox{Hipótese 1 da disjunção}\\
3.2 & \qquad \exists x Fx & \mbox{i-}\exists 3.1 \\
3.3 & \qquad \exists x Fx \lor \exists x Gx & \mbox{i-}\lor 3.2 \\
4   & Fa \to (\exists x Fx \lor \exists x Gx) & \mbox{i-}\to 3.1-3.3 \\
5.1   & \qquad Ga      & \mbox{Hipótese 2 da disjunção} \\
5.2 & \qquad \exists x Gx & \mbox{i-}\exists 5 \\
5.3 & \qquad \exists x Fx \lor \exists x Gx & \mbox{i-}\lor 5.2 \\
6  & Ga \to (\exists x Fx \lor \exists x Gx) & \mbox{i-}\to 5.1-5.3 \\
7  & \exists x Fx \lor \exists x Gx & \mbox{e-}\lor 2, 4, 6
\end{array}
$$


#### Exemplo 4

$$\neg \exists x Fx \vdash \forall x \neg Fx$$

Para provar a inexistência de um $Fa$, utilizamos a estratégia de redução ao absurdo.

$$
\begin{array}{llr}
1 & \neg \exists x Fx & \mbox{premissa}\\
2.1 & Fa        & \mbox{Hipótese de absurdo} \\
2.2 & \exists x Fx & \mbox{Introdução do existencial 2.1}\\
2.3 & \exists x Fx \land \neg \exists x Fx & \mbox{Introdução da conjunção 1,2.2}\\
3   & \neg Fa  & \mbox{Por redução ao absurdo 2.1-2.3}\\
4   & \forall x \neg Fx  & \mbox{Introdução do universal 3}
\end{array}
$$


#### Exemplo 5

$$ \neg \exists x (Fx \land \neg Gx) \vdash \forall x (Fx \to Gx)$$


$$
\begin{array}{llr}
1 & \neg \exists x (Fx \land \neg Gx) & \mbox{premissa}\\
2.1.0 & \qquad Fa             & \mbox{Hipótese para o condicional}\\
2.1.1 & \qquad\qquad \neg Ga & \mbox{Hipótese para o absurdo}\\
2.1.2 & \qquad\qquad Fa \land \neg Ga & \mbox{Introdução conjunção 2.1,2.1.1}\\
2.1.3 & \qquad\qquad \exists x (Fx \land \neg Gx) & \mbox{Introdução existencial 2.1.2}\\
2.1.4 & \qquad\qquad Ga & \mbox{Absurdo em 1 e 2.1.3}\\
2.2   & \qquad Fa \to Ga & \mbox{Introdução do condicional 2.1.0 - 2.1.4}\\\
3   & \forall x (Fx \to Gx) & \mbox{Introdução universal 2.2}
\end{array}
$$


### Regra Eliminação

A eliminação do quantificador existencial segue raciocínio contrário. Da premissa que afirma a existência de algo, por exemplo, $\exists x (Fx \land Gx)$, sabemos que para algum $x$ a propriedade é verdadeira. No entanto, não sabemos qual elemento substituir no lugar de $x$, visto que pode ser o caso de nem todos possíveis elementos satisfazerem $(Fx \land Gx)$.

Por esse motivo, para eliminarmos um quantificador existencial, temos que o fazer por meio de uma hipótese, a qual irá supor que um determinado objetvo $a$ satisfaça a propriedade em questão.

#### Exemplo 1

$$\exists (Fx \land Gx) \vdash \exists x Fx$$

$$
\begin{array}{llr}
1 & \exists x (Fx \land Gx) & \mbox{premissa}\\
2 & \qquad Fa \land Ga     &  \mbox{Hipótese para eliminação do existencial}\\
3 & \qquad Fa             &   \mbox{Eliminação da conjunção 2}\\
4 & \qquad \exists x Fx   &   \mbox{Introdução do existencial 3}\\
5 & \exists x Fx   &  \mbox{Eliminação do existencial 1, 2-4}
\end{array}
$$

#### Exemplo 2 (6.19 - pg.277)

$$ \forall x (Fx \to Gx), \exists x Fx \vdash \exists x Gx$$


#### Exemplo 3 (6.20)

$$\exists x (Fx \lor Gx) \vdash \exists x Fx \lor \exists x Gx$$


#### Exemplo 4 (6.21)

$$\exists Fx \lor \exists x Gx \vdash \exists x (Fx \lor Gx)$$
