---
layout: post
title: Exercícios IV - Equivalências e Tabelas verdade
description: 
author: jean
category: 
tags: semântica
finished: false
date: "2017-08-31 16:20"
---

**Conteúdo**
- Do not remove
{:toc}

# Equivalências
Demonstre as equivalências a seguir:

$$ (p \to q) \dashv\vdash \neg(p \land \neg q)$$

$$\neg(p \land q) \dashv\vdash (\neg p \lor \neg q) \tag{Lei de De Morgan (DM)}$$ 

$$\neg(p \lor q) \dashv\vdash (\neg p \land \neg q) \tag{Lei de De Morgan (DM)}$$

$$(p\lor q) \dashv\vdash (q\lor p) \tag{Comutação (COM)}$$

$$(p \land q) \dashv\vdash (q\land p) \tag{Comutação (COM)}$$

$$(p \lor (q \lor r)) \dashv\vdash ((p\lor q)\lor r) \tag{Associação (ASSOC)}$$

$$(p \land (q \land r))\dashv\vdash((p\land q)\land r) \tag{Associação (ASSOC)}$$

$$(p \land (q \lor r )) \dashv\vdash ((p \land q) \lor (p \land r)) \tag{Distribuição (DIST)}$$

# Tabelas verdade

Verifique se as formas de argumento a seguir são **válidas** ou **inválidas**:

$$p\to q, p\to \neg q \vdash \neg p$$

$$p\to q \vdash \neg(q\to p)$$

$$p \lor q, q \lor r \vdash p \lor r$$ 

$$\neg p \vdash p \to \neg p$$

$$p \lor q \vdash p \land q$$

$$p \to \neg q \vdash \neg(p \land q)$$

$$p\vdash (p\to (q \land p))\to (p \land q)$$

$$p\lor q, \neg p, \neg q \vdash r$$

$$(q\land r) \to p, \neg q, \neg r \vdash \neg p$$

$$p \to (r \lor s), (r \land s)\to q \vdash p\to q$$

Verifique se as fórmulas a seguir são **satisfazíveis** (tautologia?) ou **insatisfatíveis**

$$p \lor (\neg(q\land(r\to q)))$$

$$(p\land q) \to (p \lor q)$$

$$( (p\to\neg q) \to \neg p) \to q$$

$$(p\to q) \lor (p\to \neg q)$$

$$p \to \neg p$$

$$\neg(p \to p)$$

$$(p\lor q )\to p$$

$$(p\land q) \to p$$

$$p \leftrightarrow \neg(p\lor q)$$

$$ \neg((p\land q)\leftrightarrow(p\lor q))$$

$$(p\land q) \land \neg(p\lor r)$$

$$(p\to(q\land r))\to(p\to r)$$


# Referências

  - [Logica - John Nolt (PDF). Capítulo 4: Pgs. 160 a 184](https://racionalistasusp.files.wordpress.com/2010/01/nolt-john-rohatyn-dennis-lc3b3gica.pdf)
