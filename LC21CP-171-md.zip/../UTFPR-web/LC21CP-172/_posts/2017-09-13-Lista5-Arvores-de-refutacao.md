---
layout: post
title: Lista V - Árvores de refutação
description: 
author: jean
category: 
tags: semântica
finished: false
date: "2017-09-13 10:20"
---

**Conteúdo**
- Do not remove
{:toc}


# 1. Validade de argumentos

Verifique se as formas de argumento a seguir são válidas ou inválidas utilizando árvores de refutação.

$$\neg p \vdash p \to \neg p$$

$$p \to \neg q \vdash \neg (p\land q)$$

$$p\lor q, \neg p, \neg q \vdash r$$

$$\neg (p\lor q), r\leftrightarrow p \vdash \neg r$$

$$p\leftrightarrow q, q \leftrightarrow r \vdash p \leftrightarrow r$$


# 2. Satisfazibilidade de fórmulas

Verifique se as fórmulas a seguir são satifazíveis, caso afirmativo, verifique se são tautologias.

$$p \to p$$

$$\neg(p\to p)$$

$$(p\lor q)\to p$$

$$p \leftrightarrow \neg(p\lor q)$$

$$(p\land q) \land \neg(p\lor r)$$


# Referências
Capítulo 4: Pgs. 185 - 203, [Logica - John Nolt (PDF).](https://racionalistasusp.files.wordpress.com/2010/01/nolt-john-rohatyn-dennis-lc3b3gica.pdf)
