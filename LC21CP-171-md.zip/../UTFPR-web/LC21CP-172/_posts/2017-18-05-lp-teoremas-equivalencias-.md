---
layout: post
title: Lógica de predicados - Teoremas e regras de equivalência
description: 
author: jean
category: 
tags: predicados
finished: false
date: "2017-10-18 10:20"
---

**Conteúdo**
- Do not remove
{:toc}


# Teoremas

Assim como na lógica proposicional, existem fórmulas na lógica de predicados que podem ser demonstradas sem a necessidade de premissas. Tais fórmulas, chamadas *teoremas*, são verdades lógicas, ou seja sua verdade é necessária de acordo com as regras da lógica de predicados. Todos os teoremas da lógica proposicional são, também, teoremas na lógica de predicados.

## Exemplo 1

O condicional quando aplicado a antecedente e consequente iguais é um teorema na lógica proposicional, $p \to p$, sendo portanto representado em forma de argumento sem premissas

$$\vdash p \to p$$

Na lógica de predicados temos a versão generalizada deste teorema, a qual é produzida pela introdução do quantificador universal.

$$\vdash \forall x (Fx\to Fx)$$

A demonstração deste teorema segue a estratégia utilizada para demonstrarmos qualquer condicional. Assumimos como hipótese o antecedente e derivamos o consequente. 

$$
\begin{array}{llr}
1 & Fa                   &   \mbox{Hipótese para prova do condicional}\\
2 & Fa\to Fa     &  \mbox{Introdução do condicional 1}\\
3 & \forall x (Fx\to Fx)             &   \mbox{Introdução do universal em 2}
\end{array}
$$

## Exemplo 2

Provemos o seguinte teorema:

$$\vdash \forall x Fx \to Fa$$

A estratégia de demonstração é a mesma, basta observarmos que $Fa$ é uma instância da fórmula generalizada $\forall x Fx$. Portanto

$$
\begin{array}{llr}
1 & \forall x Fx                   &   \mbox{Hipótese para prova do condicional}\\
2 & \qquad Fa     &  \mbox{Eliminação do universal em 1}\\
3 & \forall x Fx\to Fa             &   \mbox{Prova do condicional 1-2}
\end{array}
$$




## Exemplo 3

$$\vdash \neg(\forall x Fx \land \exists x \neg Fx)$$

Neste exemplo, não é evidente qual regra de derivação utilizar. Seguindo a estratégia já mencionada anteriormente, tentaremos a demonstração por redução ao absurdo. Assumindo a negação da conclusão como hipótese

$$
\begin{array}{llr}
1 & \forall x Fx \land \exists x \neg Fx    &   \mbox{Hipótese para redução ao absurdo}\\
2 & \qquad \forall x Fx     &  \mbox{Eliminação do condicional em 1}\\
3 & \qquad \exists x \neg Fx     &  \mbox{Eliminação do condicional em 1}\\
4 & \qquad\quad \neg Fa          &   \mbox{Hipótese para eliminação do existencial}\\
5 & \qquad\quad Fa              &    \mbox{Eliminação do universal em 2}\\
6 & \qquad\quad p \land \neg p    &  \mbox{Pela contradição de } Fa\\
7 & \qquad p \land \neg p & \mbox{Eliminação do existencial 4-6}\\
8 & \neg(\forall x Fx \land \exists x \neg Fx) & \mbox{Redução a absurdo 1-7}
\end{array}
$$


# Equivalências

Assim como vimos para as árvores de refutação da lógica proposicional, nem sempre uma fórmula é facilmente demonstrável ou derivavel. Em alguns desses casos, no entanto, a utilização de uma fórmula equivalente facilita consideravelmente o trabalho.

Para ilustrar essa ideia, como demonstraríamos o teorema a seguir?

$$\vdash \forall x Fx \lor \exists x \neg Fx$$


Não é evidente quais regras aplicar, visto que não temos premissas, a regra de eliminação ou introdução da disjunção não são aplicáveis. Podemos então tentar substituir essa fórmula por uma equivalente, mas qual utilizar? Na lógica proposicional demonstramos a equivalência $p \to q \dashv\vdash \neg p \lor q$, seria essa quivalência válida na lógica de predicados.

## Exemplo 1

Demonstre a equivalência

$$\forall x Fx \lor \exists x \neg Fx \dashv\vdash \neg\forall x Fx \to \exists x \neg Fx$$

Dada a equivalência acima, demonstrar o teorema $\vdash \forall x Fx \lor \exists x \neg Fx$ é equivalente a demonstrar sua equivalência

$$\vdash \neg\forall x Fx \to \exists x \neg Fx$$

## Exemplo 2

Demonstre a equivalência

$$\forall x(Fx \to \neg Gx) \dashv\vdash \neg \exists x(Fx \land Gx)$$

## Exemplo 3

Demonstre as equivalências

$$\neg \forall x \neg Fx \dashv \vdash \exists x Fx \label{eq:1}$$

$$\neg \forall x Fx \dashv \vdash \exists x \neg Fx \label{eq:2}$$

$$\forall x \neg Fx \dashv\vdash \neg \exists x Fx \label{eq:3}$$

$$\forall x Fx \dashv\vdash \neg \exists x \neg Fx \label{eq:4}$$

# Intercâmbio de quantificadores

As últimas equivalências, descritas no Exemplo 3, são mais genéricas do que parecem à primeira vista. De fato, elas são válidas para quaiquer subfórmulas, desde que sejam subfórmulas dependentes da mesma variável. No entanto, para formalizarmos essa ideia, precisamos definir antes alguns conceitos.

## Variáveis abertas e fechadas

Consideremos como exemplo simples a fórmula $\forall x Fx$. Pela definição das regras de formação da linguagem da lógica de predicados, sabemos que $Fx$ só faz sentido, se houver antes um quantificador discriminando $x$. 

  - Uma fórmula é dita fechada em relação a uma variável $x$ qualquer, se existe um quantificador associado a tal variável. Exemplo: $\forall x (Fx \land Gx)$
  - Uma fórmula é dita aberta em relação a uma variável $x$ qualquer, se não existe quantificador que discrimine tal variável. Exemplo: $Fx \land Gx$, $\forall y Fxy$
  
Essa terminologia permite nos referirmos mais facilmente a fórmulas e subfórmulas com a mesma característica em termos de variáveis. Para melhor exemplificar, consideremos a equivalência $\eqref{eq:4}$ descrita anteriormente.

Nela, podemos nos referir $Fx$ como uma fórmula **aberta em $x$** enquanto $\forall x Fx$ é uma fórmula **fechada em $x$**. Obviamente, existem diversas outras fórmulas abertas em $x$. Por exemplo $Fx\land Gx$ e $Fx\to Gx$ são ambas fórmulas abertas em $x$. Ou seja, todas elas compartilham essa mesma característica com $Fx$. Podemos então, expressar ideias como 

"Seja qualquer fórmula $\phi$ que seja aberta em $\beta$". 

Em que $\beta$ represente qualquer variável, e.g. $x, y, z,\dots$. Isso nos permite generalizar as equivalências $\eqref{eq:1}-\eqref{eq:4}$ para além de $Fx$, da seguinte forma:
  
$$\neg \forall \beta \neg \phi \dashv \vdash \exists \beta \phi \label{eq:5}$$

$$\neg \forall \beta \phi \dashv \vdash \exists \beta \neg \phi$$

$$\forall \beta \neg \phi \dashv\vdash \neg \exists \beta \phi$$

$$\forall \beta \phi \dashv\vdash \neg \exists \beta \neg \phi \label{eq:8}$$


## Exemplo

Vejamos um exemplo da aplicação dessa generalização. Considere a forma de argumento a seguir:

$$\forall x (Fx \to \neg Gx) \vdash \neg \exists x (Fx \land Gx)$$

Neste exemplo, $(Fx\to\neg Gx)$ e $(Fx \land Gx)$ são fórmulas abertas em $x$. Se dermos um nome mais simples para cada uma delas, por exemplo, $\phi$ e $\psi$, respectivamente. Então a forma de argumento acima é instância de algo mais genérico

$$\forall x \phi \vdash \exists x \psi$$

## Qual a utilidade?

A principal utilidade desse tipo de generalização é nos permitir utilizar as equivalências em um contexto amplo, sem necessariamente ter que provar cada uma delas, mostrando que todas são instâncias dos mesmos teoremas. Em outras palavras, se:

$$\vdash \forall x \neg Fx  \leftrightarrow \neg \exists Fx$$

Então o teorema a seguir também é verdadeiro

$$\vdash \forall x \neg (Fx \land Gx)  \leftrightarrow \neg \exists (Fx \land Gx)$$

pois ambos são instâncias do mesmo teorema genérico. 

$$\vdash \forall \beta \neg \phi \leftrightarrow \neg \exists\beta \phi$$

Este tipo de intercâmbio entre equivalências em muitos casos torna as demonstrações muito mais simples.

### Exemplo 

Demonstre o seguinte teoremas

$$\vdash \forall x  Fx \lor \exists x \neg Fx$$

Iniciaremos com a tautologia 

$$\forall x Fx \lor \neg \forall x Fx$$ 

A subfórmula $\neg \forall x Fx$ pode ser interpretada como 

"Nem todo x satisfaz o predicado F"

Que por sua vez é equivalente a dizermos que

"Existe x que não satisfaz F"

A segunda versão pode ser escrita simbolicamente como $\exists x \neg Fx$. Esta equivalência está representada em $\eqref{eq:2}$. Substituindo essa equivalência na tautologia acima, produzimos 

$$\forall x Fx \lor \exists x \neg Fx$$

O qual finaliza a demonstração do teorema.  
