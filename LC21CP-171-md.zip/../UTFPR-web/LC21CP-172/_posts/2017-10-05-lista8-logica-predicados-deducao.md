---
layout: post
title: Lista VIII - Lógica de predicados, dedução
description: 
author: jean
category: 
tags: predicados
finished: false
date: "2017-10-05 10:00"
---
**Conteúdo**
- Do not remove
{:toc}

# Exercícios

$$\forall x Fx \vdash Fa \land (Fb \land (Fc \land Fd))$$

$$\forall x(Fx \lor Gx), \neg Fa \vdash \neg Ga$$

$$\neg Fa \vdash \neg \forall x (Fx \land Gx)$$

$$\forall x(Fx \leftrightarrow r), r \vdash Fa$$

$$\forall x(\neg Fx \lor \neg Gx) \vdash \neg(Fa \land Ga)$$

$$\forall x(Fx \to Gx) \vdash \forall x(\neg Gx \to \neg Fx)$$

$$\forall x(Fx \to Gx) \vdash \forall x\neg Gx \to \forall x \neg Fx$$

$$\forall x \forall y Fxy \vdash \forall x Fxx$$

$$\forall x Fx \vdash \forall x Gx \to \forall x (Fx \land Gx)$$

$$\forall x \forall y(Fxy \to \neg Fyx) \vdash \forall x \neg Fxx$$

$$\forall x Fx \vdash \exists x Fx$$

$$\neg \exists x Fx \vdash \neg Fa$$

$$\exists x \neg Fx \vdash \neg \forall x Fx$$

$$\forall x(Fx \to Gx) \vdash \exists x Fx \to \exists x Gx$$

$$\neg \exists x (Fx \land Gx) \vdash \forall x (\neg Fx \lor \neg Gx)$$

$$\neg \forall x(Fx \land Gx) \vdash \exists x(\neg Fx \lor \neg Gx)$$

$$\neg \exists x \exists y Lxy \vdash \forall x \neg Lxx$$

$$\eixsts x Fx \vdash \exists x \exists y(Fx \land Fy)$$

$$\forall x \neg Fx \vdash \forall x(Fx \to Gx)$$

$$\forall x \neg Fx \vdash \forall x(Fx \to \neg Gx)$$ 

# Referências

Seção 2.1: Pg. 71, [Logica - Huth & Ryan (PDF).](http://www.cse.chalmers.se/edu/course/DAT060/huthryan_lics2_sol.pdf)

Capítulo 6: Pgs. 254-284, [Logica - John Nolt (PDF).](https://racionalistasusp.files.wordpress.com/2010/01/nolt-john-rohatyn-dennis-lc3b3gica.pdf)
