---
layout: post
title: Lista VIII - Lógica de predicados, dedução
description: 
author: jean
category: 
tags: predicados
finished: false
date: "2017-10-05 10:00"
---
**Conteúdo**
- Do not remove
{:toc}

# Exercícios

## #0 Predicados unários

Interpretando como 

  + $c$: "está chovendo"
  + $R$: "é uma rã"
  + $V$: "é verde"
  + $S$: "é saltitante"
  + $I$: "é iridescente"
  
Formalize as seguintes sentenças:

  a. Todas as rãs são verdes
  
  b. Nenhuma rã é verdes
  
  c. Algumas rãs são verdes
  
  d. Algumas rãs não são verdes
  
  e. Toda coisa é uma rã.
  
  f. Alguma coisa é uma rã.
  
  g. Nem toda coisa é uma rã.
  
  h. Nada é uma rã.
  
  i. Existem rãs verdes
  
  j. Qualquer coisa ou é rã ou é iridescente.
  
  k. Qualquer coisa é uma rã verde.
  
  l. Está chovendo e algumas rãs estão saltitando
  
  m. Se está chovendo, então todas as rãs estão saltitando
  
  n. Algumas coisas são verdes e algumas não são
  
  o. Algumas coisas são verdes e iridescentes simultaneamente
  
  p. Ou qualquer coisa é uma rã, ou nada é uma rã
  
  q. Qualquer coisa ou é uma rã ou não é uma rã.
  
  r. Todas as rãs são rãs.
  
  s. Somente rãs são verdes.
  
  t. Não existem rãs iridescentes.
  
  u. Todas as rãs verdes estão saltitando
  
  v. Algumas rãs verdes não estão saltitando
  
  w. Não é verdade que algumas rãs verdes estão saltitando.
  
  x. Se nada é verde, então não existem rãs verdes.
  
  y. Rãs verdes saltam se e somente se não está chovendo. 

## #1  Predicados binários

Use os predicados

  + $A(x,y)$: $x$ admira $y$
  + $B(x,y)$: $x$ estava presente em $y$
  + $P(x)$: $x$ é um professor
  + $E(x)$: $x$ é um estudante
  + $L(x)$: $x$ é uma aula
  
e o símbolo funcional (constante)

  + $m$: Maria
  
  a. Maria admira todo professor
  
  b. Algum professor admira Maria
  
  c. Maria admira a si própria
  
  d. Nenhum estudante estava presente em todas as aulas.
  
  e. Nenhuma aula teve a presença de todos os estudantes
  
  f. Nenhuma aula teve a presença de qualquer estudante.


## #2 Predicados binários
Suponha 
  + $F(x,y)$: $x$ é o pai de $y$
  + $M(x,y)$: $x$ é a mãe de $y$
  + $H(x,y)$: $x$ é marido de $y$
  + $S(x,y)$: $x$ é irmã de $y$
  + $B(x,y)$: $x$ é irmão de $y$
  
É permitido usar constantes para representar nomes: 'Ed', 'Patsy'

  a. Todos têm uma mãe
  
  b. Todos têm um pai e uma mãe
  
  c. Todos que tem uma mãe tem um pai
  
  d. Ed é um avô
  
  e. Todos os pais são pais ou mães
  
  f. Todos os maridos são cônjuges
  
  g. Nenhum tio é tia
  
  h. Todos os irmãos são irmãos ou irmãs
  
  i. Nenhuma avó é pai de alguém
  
  j. Ed e Patsy são marido e mulher
  
  k. Carlos é cunhado de Monique.
  
## #3 Fórmulas bem formadas

Sejam $m$ uma constante, $f$ um símbolo funcional unário e $S$ e $B$ dois símbolos predicados binários. Quais das cadeias a seguir são fórmulas na lógica de predicados.

$$S(m)$$

$$B(m, f(m))$$

$$B(B(m,x),y)$$



# Referências

Seção 2.1: Pg. 71, [Logica - Huth & Ryan (PDF).](http://www.cse.chalmers.se/edu/course/DAT060/huthryan_lics2_sol.pdf)

Capítulo 6: Pgs. 239, [Logica - John Nolt (PDF).](https://racionalistasusp.files.wordpress.com/2010/01/nolt-john-rohatyn-dennis-lc3b3gica.pdf)
