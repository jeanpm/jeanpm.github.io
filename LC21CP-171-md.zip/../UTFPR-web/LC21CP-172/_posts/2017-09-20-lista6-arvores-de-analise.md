---
layout: post
title: Lista VI - Árvores de análise e formas normais
description: 
author: jean
category: 
tags: formalização
finished: false
date: "2017-09-21 18:20"
---


# Exercícios

## Fórmulas bem formuladas

Dadas as fórmulas a seguir, construa suas árvores de análise e diga quais são bem formuladas:

$$p \land q$$

$$p\land \neg(p \lor q \land s) \to (r\to s)$$

$$p \land \neg q \to \neg p$$

$$p \land (\neg q \to \neg p)$$

$$\neg((\neg q \land (p\to r))\land (r\to q))$$

$$p\land \neg(p\lor \land s) \to (r \to s)$$

$$(p\land q)\to (\neg r\lor(q \to r))$$

$$ (((s\to(r\lor \ell))\lor((\neg q)\land r))\to((\neg(p\to s))\to r))$$


## Subfórmulas

Para cada uma das fórmulas, construa suas árvores de análise e liste todas subfórmulas.

$$p \to (\neg p \lor (\neg\neg q \to (p\land q)))$$

$$(s \to r \lor \ell) \lor (\neg q\land r) \to (\neg(p \to s) \to r)$$

$$(p\to q) \land (\neg r \to (q \lor(\neg p\land r)))$$ 

$$\neg(s\to(\neg(p\to(q\lor\neg s))))$$

$$((p\to \neg q))\lor(p\land r)\to s) \lor \neg r$$


## Formas normais

Transformar as seguinte fórmulas para a forma normal conjuntiva e disjuntiva (FNC, FND), utilizando tabelas-verdade. Verificar se algumas das fórmulas contém cláusulas de Horn.

$$ ((p\to q)\to p)\to p $$


$$\neg(p\land \neg p)$$

$$(p\lor q)\to \neg(q \lor r)$$

$$(p\to q) \leftrightarrow (r\land p)$$

$$(p\leftrightarrow q) \to (p \lor q)$$

# Referências
Capítulo 4: Pgs. 185 - 203, [Logica - John Nolt (PDF).](https://racionalistasusp.files.wordpress.com/2010/01/nolt-john-rohatyn-dennis-lc3b3gica.pdf)
