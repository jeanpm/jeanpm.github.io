---
layout: post
title: Lógica de predicados - Regras de dedução I  
description: 
author: jean
category: 
tags: predicados
finished: false
date: "2017-10-04 10:20"
---

**Conteúdo**
- Do not remove
{:toc}


# Regras de inferência

O cálculo de predicados usa as mesmas dez regras do cálculo proposicional. Adicionalmente, temos as regras de introdução e de eliminação dos quantificadores. Relembremos um exemplo do cálculo proposicional

$$\neg r \lor q, q \to p \vdash r \to p$$ 

Este exemplo pode ser demonstrado utilizando a abordagem de prova de condicionais: assumir o antecedente como hipótese e derivar o consequente. Vejamos como ficaria

$$
\begin{array}{llr}
1 & \neg r \lor q & \mbox{premissa}\\
2 & q \to p       & \mbox{premissa}\\
3 & r             & \mbox{hipótese}\\
4 & \neg\neg r     & \mbox{Dupla negação 3}\\
5 & q            & \mbox{Silogismo disjuntivo 1,4}\\
6 & p           &  \mbox{Modus ponens 2,5}\\
7 & r \to p     & \mbox{Prova do condicional 3-6}
\end{array}
$$

Um exemplo similar na lógica de predicados, poderia ser provado utilizando-se das mesmas regras de derivação. Consideremos, por exemplo, a forma de argumento.

$$ \neg F(a) \lor \exists x F(x), \exists x F(x) \to p \vdash F(a) \to p$$

Se substituirmos as subfórmulas análogamente ao exemplo anterior, temos a demonstração a seguir:

$$
\begin{array}{llr}
1 & \neg F(a) \lor \exists x F(x) & \mbox{premissa}\\
2 & \exists x F(x) \to p       & \mbox{premissa}\\
3 & F(a)             & \mbox{hipótese}\\
4 & \neg\neg F(a)     & \mbox{Dupla negação 3}\\
5 & \exists x F(x)            & \mbox{Silogismo disjuntivo 1,4}\\
6 & p           &  \mbox{Modus ponens 2,5}\\
7 & F(a) \to p     & \mbox{Prova do condicional 3-6}
\end{array}
$$

Neste exemplo da lógica de predicados não precisamos utilizar regras de inferência para os quantificadores, deste modo a demonstração se restringiu à utilização das regras já definidas para a lógica proposicional. Como esse não é sempre o caso, precisamos especificar o funcionamento das regras de derivação para os quantificadores: *universal* ($\forall$) e *existencial* ($\exists$). 

## Quantificador universal

### Regra de eliminação
Iremos iniciar pela definição da regra de eliminação do quantificador universal ($\forall$e). Intuitivamente a regra de eliminação do quantificador universal é bem simples e segue a seguinte ideia: 

  + Se algo é valido para todos objetos, também é válido para um objeto em específico.
  
Portanto, uma fórmula geral do tipo $\forall x P(x)$, pode ser substituída durante uma demonstração por um caso específico $P(a)$, onde $a$ é um termo qualquer. Vejamos o seguinte exemplo.

"Todos os homens são mortais"

"Sócrates é homem"

"Sócrates é mortal"

Se definirmos os predicados:

  - $H(x):$ $x$ é homem
  - $M(x):$ $x$ é mortal
  - $s:$ Sócrates

Temos o seguinte argumento formalizado:

$$\forall x(H(x)\to M(x)), H(s) \vdash M(s)$$

$$
\begin{array}{llr}
1 & \forall x(H(x)\to M(x)) & \mbox{premissa}\\
2 & H(s)       & \mbox{premissa}\\
3 & H(s)\to M(s) & \mbox{Eliminação do universal 1}\\
4 & M(s)        &  \mbox{Modus Ponens 2, 3}
\end{array}
$$

O caso genérico indicado pela premissa $\forall x(H(x)\to M(x))$ pode ser especializado em termos de $s$ (Sócrates), levando à fórmula $H(s)\to M(s)$. Ou seja, se o fato de ser homem implica ser mortal, essa regra se aplica a qualquer homem $x$, inclusive Sócrates $s$. Pode-se dizer que $H(s)\to M(s)$ é uma instanciação da regra universal.

#### Exemplo 1

Prove a validade da seguinte forma de argumento

$$\forall x ~F(x)\to G(x), ~\forall x F(x) ~~~\vdash~~ G(a)$$


$$
\begin{array}{llr}
1 & \forall x ~F(x)\to G(x) & \mbox{premissa}\\
2 & \forall x F(x)       & \mbox{premissa}\\
3 & F(a)\to G(a) & \mbox{Eliminação do universal 1}\\
4 & F(a)        &  \mbox{Eliminação do universal 2}\\
5 & G(A)        &  \mbox{Modus Ponens 3, 4}
\end{array}
$$

#### Exemplo 2

Prove a validade da seguinte forma de argumento

$$\neg F(a)~~\vdash ~~\neg \forall x F(x)$$


$$
\begin{array}{llr}
1 & \neg F(a)        & \mbox{premissa}\\
2 & \forall x F(x)   & \mbox{Hipótese por absurdo}\\
3 & F(a)             & \mbox{Eliminação do universal 1}\\
4 & \neg F(a) \land F(a)       &  \mbox{Introdução do condicional 1,3}\\
5 & \neg \forall x F(x)        &  \mbox{Redução ao absurdo 2-4}
\end{array}
$$


#### Exemplo 3

$$\forall x \forall y F(x,y)~~ \vdash F(a,a)$$

$$
\begin{array}{llr}
1 & \forall x \forall y F(x,y)        & \mbox{premissa}\\
2 & \forall y F(a,y)   & \mbox{Eliminação do universal 1}\\
3 & F(a,a)      & \mbox{Eliminação do universal 2}
\end{array}
$$


### Regra de introdução

Em princípio, para introduzirmos uma fórmula do tipo $\forall x F(x)$, teríamos que demonstrar que para qualquer que seja $x$ então o predicado $P(x)$ é verdadeiro. Obviamente, sendo $x$ parte de um domínio possivelmente infinito esse tipo de abordagem não é possível. Como então introduzirmos o quantificador universal?

A ideia também é simples, apesar de um pouco confusa no início. Se eu consigo demonstrar que para um caso específico $a$, $P(a)$ é verdadeiro, então, se nenhuma consideração/restrição foi feita em termos de $a$, essa demonstração poderia ser utilizada para demonstrar que para qualquer $x$, $P(x)$ também é verdadeiro. Consideremos um exemplo:

"Todos os peixes são ciprinídeos"

"Todos ciprinídeos são vistosos"

"Todos os peixes são vistosos"

Que formalizada por meio dos predicados:

  - $P(x)$: $x$ é peixe
  - $C(x)$: $x$ é ciprinídeo
  - $V(x)$: $x$ é vistoso
  
$$\forall x(Px\to Cx),~~\forall x(Cx\to Vx) \vdash \forall (Px\to Vx)$$

$$
\begin{array}{llr}
1 & \forall x(Px\to Cx)        & \mbox{premissa}\\
2 & \forall x(Cx\to Vx)   & \mbox{premissa}\\
3 & Pa\to Ca      & \mbox{Eliminação do universal 1}\\
4 & Ca\to Va      & \mbox{Eliminação do universal 2}\\
5 & Pa\to Va      & \mbox{Transitividade 3,4}\\
6 & \forall x(Px\to Vx)      & \mbox{Generalização universal 5}
\end{array}
$$

Apesar de $a$ neste exemplo ser utilizado para referenciar um caso específico de $x$, nenhuma suposição foi feita acerca de $a$, portanto ele poderia ser utilizado para substituir qualquer $x$. Portanto é possível generalizar a conclusão de $a$ para $\forall x$.

  - Para que a aplicação dessa regra seja válida, não pode haver suposições sobre o símbolo $a$, ou seja, ele **não pode aparecer nas premissas** nem e nenhuma **hipótese vigente**.
  - Pois nesses casos haveria suposições sobre $a$, consequentemente ele não poderia representar um $x$ arbitrário.
  
  
#### Exemplo 1

$$\forall (Fx \land Gx) ~~ \vdash ~~\forall x Fx \land \forall x Gx$$ 

$$
\begin{array}{llr}
1 & \forall (Fx \land Gx)        & \mbox{premissa}\\
2 & Fa \land Ga   & \mbox{Eliminação do universal 1}\\
3 & Fa      & \mbox{Eliminação da conjunção 2}\\
4 & Ga      & \mbox{Eliminação da conjunção 2}\\
5 & \forall x Fx      & \mbox{Introdução do universal 3}\\
6 & \forall x Gx      & \mbox{Introdução do universal 4}\\
7 & \forall x Fx \land \forall x Gx      & \mbox{Introdução da conjunção 5, 6}
\end{array}
$$


#### Exemplo 2

$$\forall x (Fx \to (Gx \lor Hx)), \forall x \neg Gx  \vdash \forall x Fx \to \forall x Hx$$

$$
\begin{array}{llr}
1 & \forall x (Fx \to (Gx \lor Hx))        & \mbox{premissa}\\
2 & \forall x \neg Gx   & \mbox{premissa}\\
3 & Fa \to (Ga \lor Ha)      & \mbox{Eliminação do universal 1}\\
4 & \neg Ga      & \mbox{Eliminação do universal 2}\\
5 & \qquad \forall x Fx      & \mbox{Hipótese do condicional}\\
6 & \qquad Fa      & \mbox{Eliminação do universal 5}\\
7 & \qquad Ga \lor Ha      & \mbox{Modus Ponens 3, 6}\\
8 & \qquad Ha             & \mbox{Silogismo disjuntivo 4,7}\\
9 & \qquad\forall x Hx   & \mbox{Introdução do universal 8}\\
10 & \forall x Fx \to \forall x Hx & \mbox{Prova do condicional 5-9}
\end{array}
$$


#### Exemplo 3

$$\forall x (Fx \to (Gx \lor Hx)), \forall x \neg Gx  \vdash \forall x (Fx \to Hx)$$

$$
\begin{array}{llr}
1 & \forall x (Fx \to (Gx \lor Hx))        & \mbox{premissa}\\
2 & \forall x \neg Gx   & \mbox{premissa}\\
3 & Fa \to (Ga \lor Ha)      & \mbox{Eliminação do universal 1}\\
4 & \neg Ga      & \mbox{Eliminação do universal 2}\\
5 & \qquad Fa      & \mbox{Hipótese do condicional}\\
6 & \qquad Ga \lor Ha      & \mbox{Modus Ponens 3, 5}\\
7 & \qquad Ha             & \mbox{Silogismo disjuntivo 4,7}\\
8 & Fa \to Ha   & \mbox{Prova do condicional 5-7}\\
9 & \forall x (Fx \to Hx) & \mbox{Introdução do universal 8}
\end{array}
$$

#### Exemplo 4

$$\forall x Fax, \forall x \forall y (Fxy \to Gyx) \vdash \forall x Gxa$$

$$
\begin{array}{llr}
1 & \forall x Fax        & \mbox{premissa}\\
2 & \forall x \forall y (Fxy \to Gyx)  & \mbox{premissa}\\
3 & Fab      & \mbox{Eliminação do universal 1}\\
4 & \forall y (Fay \to Gya)      & \mbox{Eliminação do universal 2}\\
5 & Fab \to Gba      & \mbox{Eliminação do universal 4}\\
6 & Gba      & \mbox{Modus Ponens 3, 5}\\
7 & \forall x Gxa             & \mbox{Introdução do universal 6}
\end{array}
$$

#### Exemplo 5

$$\forall x Fx \to \forall x Gx, \neg Ga \vdash \neg \forall x Fx$$

$$
\begin{array}{llr}
1 & \forall x Fx \to \forall x Gx        & \mbox{premissa}\\
2 & \neg Ga  & \mbox{premissa}\\
3 & \qquad \forall x Fx      & \mbox{Hipótese para absurdo}\\
4 & \qquad \forall x Gx      & \mbox{Modus Ponens 1, 3}\\
5 & \qquad Ga      & \mbox{Eliminação do universal 4}\\
6 & \qquad Ga \land \neg Ga      & \mbox{Introdução da conjunção 2,5}\\
7 & \neg \forall x Fx             & \mbox{Redução ao absurdo 3-6}
\end{array}
$$
